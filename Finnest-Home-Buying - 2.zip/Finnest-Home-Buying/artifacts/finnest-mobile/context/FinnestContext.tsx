import React, { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter, type Href } from 'expo-router';
import { Text, View, StyleSheet } from 'react-native';
import colors from '@/constants/colors';
import { blankProfile, initialState, storageKey, newSteps, resaleSteps, type AppState, type Screen, type Ctx } from '@/lib/data';

type ContextValue = Ctx & {
  nav: (screen: Screen) => void; toast: string; isLoading: boolean; ready: boolean;
  storageError: string; retryStorage: () => void;
};
const FinnestContext = createContext<ContextValue | null>(null);
const routes: Record<Screen, Href> = {
  Home: '/(tabs)', Journey: '/(tabs)/journey', Experts: '/(tabs)/experts',
  About: '/(tabs)/about', Documents: '/documents', 'Red Flags': '/red-flags',
};

function restore(raw: string | null): AppState {
  if (!raw) return { ...initialState, profile: { ...blankProfile } };
  const saved: unknown = JSON.parse(raw);
  if (!saved || typeof saved !== 'object' || Array.isArray(saved)) throw new Error('Invalid saved progress.');
  const candidate = saved as Partial<AppState>;
  if (candidate.onboarded !== undefined && typeof candidate.onboarded !== 'boolean') throw new Error('Invalid saved progress.');
  if (candidate.projects !== undefined && !Array.isArray(candidate.projects)) throw new Error('Invalid saved projects.');
  for (const project of candidate.projects ?? []) {
    if (!project || typeof project.id !== 'number' || typeof project.name !== 'string') throw new Error('Invalid saved project.');
  }
  for (const key of ['checked', 'values', 'selected', 'notes'] as const) {
    const map = candidate[key];
    if (map !== undefined && (!map || typeof map !== 'object' || Array.isArray(map))) throw new Error('Invalid saved progress.');
  }
  return { ...initialState, ...candidate, profile: { ...blankProfile, ...candidate.profile } };
}

export function FinnestProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [state, setState] = useState<AppState>(initialState);
  const [isLoading, setLoading] = useState(true);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState('');
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [toast, setToast] = useState('');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const writeQueue = useRef<Promise<void>>(Promise.resolve());
  const currentState = useRef(state);
  currentState.current = state;

  useEffect(() => {
    let active = true;
    setLoading(true);
    AsyncStorage.getItem(storageKey).then(raw => {
      const restored = restore(raw);
      if (!active) return;
      setState(restored);
      setReady(true);
      setStorageError('');
    }).catch(() => {
      if (active) setStorageError('Your saved progress could not be loaded. Nothing has been overwritten. Please retry.');
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [loadAttempt]);

  const persist = (snapshot: AppState) => {
    const serialized = JSON.stringify(snapshot);
    writeQueue.current = writeQueue.current
      .catch(() => undefined)
      .then(() => AsyncStorage.setItem(storageKey, serialized))
      .then(() => { setStorageError(''); })
      .catch(() => { setStorageError('Changes are kept in memory but could not be saved on this device. Please retry before closing the app.'); });
  };
  useEffect(() => { if (ready) persist(state); }, [state, ready]);
  useEffect(() => {
    if (!toast) return undefined;
    const timer = setTimeout(() => setToast(''), 3000);
    return () => clearTimeout(timer);
  }, [toast]);

  const nav = (screen: Screen) => {
    setState(s => ({ ...s, activeScreen: screen }));
    router.navigate(routes[screen]);
  };
  const openStep = (index: number) => {
    const steps = state.propertyType === 'Resale Property' ? resaleSteps : newSteps;
    setState(s => ({ ...s, activeScreen: 'Journey', step: Math.max(0, Math.min(steps.length - 1, index)) }));
    router.navigate('/(tabs)/journey');
  };
  const openExperts = (category: string) => {
    setState(s => ({ ...s, activeScreen: 'Experts', expertCategory: category }));
    router.navigate('/(tabs)/experts');
  };
  const value: ContextValue = {
    state, setState, nav, openStep, openExperts, expanded, setExpanded, toast, setToast,
    isLoading, ready, storageError,
    retryStorage: () => { if (ready) persist(currentState.current); else setLoadAttempt(attempt => attempt + 1); },
    toggleCheck: key => setState(s => ({ ...s, checked: { ...s.checked, [key]: !s.checked[key] } })),
    putValue: (key, val) => setState(s => ({ ...s, values: { ...s.values, [key]: val } })),
    putNote: (key, val) => setState(s => ({ ...s, notes: { ...s.notes, [key]: val } })),
    togglePick: (group, item) => setState(s => {
      const picks = s.selected[group] ?? [];
      return { ...s, selected: { ...s.selected, [group]: picks.includes(item) ? picks.filter(p => p !== item) : [...picks, item] } };
    }),
  };
  return <FinnestContext.Provider value={value}>
    {children}
    {!!toast && <View pointerEvents="none" style={styles.toast}><Text accessibilityLiveRegion="polite" style={styles.toastText}>{toast}</Text></View>}
  </FinnestContext.Provider>;
}
export function useFinnest() {
  const context = useContext(FinnestContext);
  if (!context) throw new Error('useFinnest must be used within FinnestProvider.');
  return context;
}
const styles = StyleSheet.create({
  toast: { position: 'absolute', left: 20, right: 20, bottom: 110, padding: 15, backgroundColor: colors.light.foreground, borderRadius: colors.radius, zIndex: 100 },
  toastText: { color: colors.light.primaryForeground, fontSize: 14, textAlign: 'center' },
});
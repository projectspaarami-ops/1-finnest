import { RedFlagsScreen } from '@/screens/MainScreens';

export default RedFlagsScreen;
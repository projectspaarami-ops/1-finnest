import { DocumentsScreen } from '@/screens/MainScreens';

export default DocumentsScreen;
import { OnboardingScreen } from '@/screens/MainScreens';

export default OnboardingScreen;
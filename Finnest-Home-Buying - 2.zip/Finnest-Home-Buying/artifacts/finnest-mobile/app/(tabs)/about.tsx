import { AboutScreen } from '@/screens/MainScreens';

export default AboutScreen;
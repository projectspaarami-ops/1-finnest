import React from 'react';
import { Platform, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { isLiquidGlassAvailable } from 'expo-glass-effect';
import { Tabs, Redirect } from 'expo-router';
import { NativeTabs } from 'expo-router/unstable-native-tabs';
import { useFinnest } from '@/context/FinnestContext';

function NativeTabLayout() {
  return <NativeTabs backBehavior="history">
    <NativeTabs.Trigger name="index"><NativeTabs.Trigger.Icon sf={{ default: 'house', selected: 'house.fill' }}/><NativeTabs.Trigger.Label>Home</NativeTabs.Trigger.Label></NativeTabs.Trigger>
    <NativeTabs.Trigger name="journey"><NativeTabs.Trigger.Icon sf={{ default: 'list.bullet', selected: 'list.bullet' }}/><NativeTabs.Trigger.Label>Journey</NativeTabs.Trigger.Label></NativeTabs.Trigger>
    <NativeTabs.Trigger name="experts"><NativeTabs.Trigger.Icon sf={{ default: 'person.2', selected: 'person.2.fill' }}/><NativeTabs.Trigger.Label>Experts</NativeTabs.Trigger.Label></NativeTabs.Trigger>
    <NativeTabs.Trigger name="about"><NativeTabs.Trigger.Icon sf={{ default: 'info.circle', selected: 'info.circle.fill' }}/><NativeTabs.Trigger.Label>About</NativeTabs.Trigger.Label></NativeTabs.Trigger>
  </NativeTabs>;
}
function ClassicTabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isIOS = Platform.OS === 'ios';
  const isWeb = Platform.OS === 'web';
  return <Tabs backBehavior="history" screenOptions={{
    headerShown: false,
    tabBarActiveTintColor: colors.primary,
    tabBarInactiveTintColor: colors.mutedForeground,
    tabBarHideOnKeyboard: true,
    tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
    tabBarStyle: {
      backgroundColor: isIOS ? 'transparent' : colors.card,
      borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border,
      height: isWeb ? 84 : 60 + insets.bottom,
      paddingTop: 8, paddingBottom: isWeb ? 24 : Math.max(8, insets.bottom),
      elevation: 0,
    },
    tabBarBackground: isIOS ? () => <BlurView intensity={100} tint="light" style={StyleSheet.absoluteFill}/> : undefined,
  }}>
    <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: ({ color }) => <Feather name="home" size={22} color={color}/> }}/>
    <Tabs.Screen name="journey" options={{ title: 'Journey', tabBarIcon: ({ color }) => <Feather name="list" size={22} color={color}/> }}/>
    <Tabs.Screen name="experts" options={{ title: 'Experts', tabBarIcon: ({ color }) => <Feather name="users" size={22} color={color}/> }}/>
    <Tabs.Screen name="about" options={{ title: 'About', tabBarIcon: ({ color }) => <Feather name="info" size={22} color={color}/> }}/>
  </Tabs>;
}
export default function TabLayout() {
  const { state } = useFinnest();
  if (!state.onboarded) return <Redirect href="/onboarding"/>;
  return Platform.OS === 'ios' && isLiquidGlassAvailable() ? <NativeTabLayout/> : <ClassicTabLayout/>;
}
import { HomeScreen } from '@/screens/MainScreens';

export default HomeScreen;

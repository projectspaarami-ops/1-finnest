import { ExpertsScreen } from '@/screens/MainScreens';

export default ExpertsScreen;
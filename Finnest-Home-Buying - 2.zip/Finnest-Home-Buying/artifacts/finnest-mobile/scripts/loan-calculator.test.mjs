import assert from 'node:assert/strict';
import { compute, parseInput, yearlyBreakdown, nearbyTenures, roundTo } from '../lib/loan-calculator.ts';
const near = (a, b, t) => assert.ok(Math.abs(a - b) <= t, `${a} vs ${b}`);
const a = compute(5_000_000, 8.5, 240);
near(a.emi, 43391, 1); near(a.total, a.emi * 240, 1e-6); near(a.interest, a.total - 5_000_000, 1e-6);
const z = compute(1_200_000, 0, 120); assert.equal(z.emi, 10000); assert.equal(z.interest, 0);
const reference = compute(100000, 12, 12);
near(reference.emi, 8884.88, .01); near(reference.interest, 6618.55, .02);
assert.equal(compute(0, 8, 120), null); assert.equal(compute(100, 8, 0), null); assert.equal(compute(NaN, 8, 12), null);
assert.equal(parseInput('', 'amount').status, 'empty');
for (const [v, k] of [['-5', 'amount'], ['abc', 'rate'], ['1e5', 'amount'], ['41', 'tenure'], ['0', 'tenure'], ['0.01', 'tenure'], ['31', 'rate'], ['0', 'amount'], ['1e400', 'amount']])
  assert.equal(parseInput(v, k).status, 'invalid', v + k);
assert.equal(parseInput('2.5', 'tenure').status, 'ok'); assert.equal(parseInput('40', 'tenure').status, 'ok'); assert.equal(parseInput('0', 'rate').status, 'ok');
const x = compute(1_000_000_000, 30, 480); assert.ok(Number.isFinite(x.emi) && Number.isFinite(x.total));
const s = compute(5_000_000, 8.5, 120), l = compute(5_000_000, 8.5, 300);
assert.ok(l.emi < s.emi && l.interest > s.interest);
const rows = yearlyBreakdown(5_000_000, 8.5, 240); assert.equal(rows.length, 20); near(rows[19].closing, 0, 1e-4);
near(rows.reduce((t, r) => t + r.principalPaid, 0), 5_000_000, 1e-3);
assert.deepEqual(nearbyTenures(240), [180, 216, 240, 264, 300]);
for (const months of [1, 13, 25, 479, 480]) {
  const parsed = parseInput(roundTo(months / 12, 12), 'tenure');
  assert.equal(parsed.status, 'ok');
  assert.equal(Math.round(parsed.value * 12), months);
}
near(compute(1_200_000, 1e-20, 120).emi, 10000, 1e-6);
for (const args of [[100, 8, 2.5], [100, 8, 481], [100, 31, 12], [1_000_000_001, 8, 12]]) assert.equal(compute(...args), null);
console.log('loan-calculator tests passed');

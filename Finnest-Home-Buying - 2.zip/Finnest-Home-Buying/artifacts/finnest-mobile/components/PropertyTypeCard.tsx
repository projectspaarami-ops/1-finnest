import { useEffect, useState } from 'react';
import { Platform, Pressable, StyleSheet, View } from 'react-native';
import Animated, { interpolateColor, ReduceMotion, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import colors from '@/constants/colors';
import { Icon, T } from '@/components/ui';

type PropertyType = 'New Property' | 'Resale Property';
const palette = colors.light;
const timing = { duration: 200, reduceMotion: ReduceMotion.System };

/** Native radio semantics, with the same selection exposed to the web preview. */
export function PropertyTypeCard({ kind, selected, onSelect }: {
  kind: PropertyType; selected: boolean; onSelect: () => void;
}) {
  const [focused, setFocused] = useState(false);
  const selection = useSharedValue(selected ? 1 : 0);
  const scale = useSharedValue(1);
  const subtitle = kind === 'New Property' ? 'Under Construction' : 'Existing Home';
  useEffect(() => { selection.value = withTiming(selected ? 1 : 0, timing); }, [selected, selection]);
  const cardStyle = useAnimatedStyle(() => ({
    borderColor: interpolateColor(selection.value, [0, 1], [palette.border, palette.primary]),
    borderWidth: 1 + selection.value,
    backgroundColor: interpolateColor(selection.value, [0, 1], [palette.card, palette.secondary]),
    transform: [{ scale: scale.value }],
  }));
  const radioStyle = useAnimatedStyle(() => ({
    borderColor: interpolateColor(selection.value, [0, 1], [palette.border, palette.primary]),
    backgroundColor: interpolateColor(selection.value, [0, 1], [palette.card, palette.primary]),
  }));
  const dotStyle = useAnimatedStyle(() => ({
    opacity: selection.value,
    transform: [{ scale: .5 + selection.value * .5 }],
  }));
  return <View style={[styles.focusRing, focused && { borderColor: palette.primary }]}>
    <Animated.View style={[styles.card, cardStyle]}>
      <Pressable
        accessibilityRole="radio" accessibilityState={{ checked: selected }}
        accessibilityLabel={`${kind}, ${subtitle}`} accessibilityHint="Choose this property type"
        testID={`onboarding-type-${kind === 'New Property' ? 'new' : 'resale'}`}
        focusable onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        onPressIn={() => { scale.value = withTiming(.98, { ...timing, duration: 90 }); }}
        onPressOut={() => { scale.value = withTiming(1, timing); }}
        onPress={() => {
          if (Platform.OS !== 'web') void Haptics.selectionAsync().catch(() => undefined);
          onSelect();
        }} style={styles.content}>
        <Icon name={kind === 'New Property' ? 'home' : 'key'} size={30} color={selected ? palette.primary : palette.mutedForeground}/>
        <View style={styles.labels}>
          <T variant="label" style={styles.center}>{kind}</T>
          <T muted style={styles.subtitle}>{subtitle}</T>
        </View>
        <Animated.View pointerEvents="none" style={[styles.radio, radioStyle]}><Animated.View style={[styles.dot, dotStyle]}/></Animated.View>
      </Pressable>
    </Animated.View>
  </View>;
}
const styles = StyleSheet.create({
  focusRing: { borderWidth: 2, borderColor: 'transparent', borderRadius: colors.radius + 2, padding: 2 },
  card: { width: '100%', aspectRatio: 1.15, borderRadius: colors.radius, overflow: 'hidden' },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 22, padding: 24, paddingBottom: 38, minHeight: 44 },
  labels: { gap: 6 },
  center: { textAlign: 'center' },
  subtitle: { textAlign: 'center', fontSize: 15 },
  radio: { width: 22, height: 22, borderRadius: 11, borderWidth: 1.5, position: 'absolute', bottom: 16, right: 16, justifyContent: 'center', alignItems: 'center' },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: palette.primaryForeground },
});
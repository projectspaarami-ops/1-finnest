import { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { useFinnest } from '@/context/FinnestContext';
import { currency } from '@/lib/data';
import {
  compute, fmtYears, nearbyTenures, parseInput, roundTo, yearlyBreakdown, MAX_MONTHS, MAX_RATE, type Kind, type Parsed,
} from '@/lib/loan-calculator';
import { Banner, Card, Disclaimer, Field, Icon, T } from '@/components/ui';
import LoanSlider from '@/components/LoanSlider';
import colors from '@/constants/colors';

const palette = colors.light;
const EXAMPLE: Record<string, string> = { loanamount: '100000', rate: '12', tenure: '1' };
const SIZE = 200, STROKE = 22, R = (SIZE - STROKE) / 2, C = 2 * Math.PI * R;

function Donut({ principal, interest }: { principal: number; interest: number }) {
  const total = principal + interest;
  const ip = total > 0 ? interest / total : 0;
  const arc = C * ip;
  return <Svg width={SIZE} height={SIZE} viewBox={`0 0 ${SIZE} ${SIZE}`}>
    <Circle cx={SIZE / 2} cy={SIZE / 2} r={R} stroke={palette.chartPrincipal} strokeWidth={STROKE} fill="none" />
    {arc > 0 && <Circle cx={SIZE / 2} cy={SIZE / 2} r={R} stroke={palette.chartInterest} strokeWidth={STROKE} fill="none"
      strokeDasharray={`${arc} ${C - arc}`} transform={`rotate(-90 ${SIZE / 2} ${SIZE / 2})`} />}
  </Svg>;
}

export default function LoanCalculator() {
  const { state, putValue } = useFinnest();
  const [adv, setAdv] = useState(false);
  const [showYears, setShowYears] = useState(false);
  const [tenureDraft, setTenureDraft] = useState<string | null>(null);
  const v = state.values;
  const raw = (k: string) => v[k] ?? EXAMPLE[k] ?? '';
  const isExample = ['loanamount', 'rate', 'tenure'].some(k => v[k] === undefined);
  const amt = parseInput(raw('loanamount'), 'amount'), rate = parseInput(raw('rate'), 'rate');
  const savedTenure = parseInput(raw('tenure'), 'tenure');
  const draftMonths = tenureDraft === null ? null : parseInput(tenureDraft, 'income');
  const ten: Parsed = draftMonths === null ? savedTenure
    : draftMonths.status === 'empty' ? draftMonths
    : draftMonths.status === 'ok' && Number.isInteger(draftMonths.value) && draftMonths.value >= 1 && draftMonths.value <= MAX_MONTHS
      ? { status: 'ok', value: draftMonths.value / 12, error: '' }
      : { status: 'invalid', value: 0, error: 'Enter a whole number of months between 1 and 480.' };
  const inc = parseInput(v.income, 'income');
  const anyInvalid = [amt, rate, ten, inc].some(x => x.status === 'invalid');
  const ready = amt.status === 'ok' && rate.status === 'ok' && ten.status === 'ok';
  const months = ten.status === 'ok' ? Math.round(ten.value * 12) : 0;
  const result = useMemo(() => ready ? compute(amt.value, rate.value, months) : null, [ready, amt.value, rate.value, months]);
  const options = useMemo(() => ready ? nearbyTenures(months).map(m => ({ m, r: compute(amt.value, rate.value, m) })).filter(o => o.r) : [], [ready, amt.value, rate.value, months]);
  const rows = useMemo(() => adv && showYears && result ? yearlyBreakdown(amt.value, rate.value, months) : [], [adv, showYears, result, amt.value, rate.value, months]);
  const share = result && inc.status === 'ok' && inc.value > 0 ? result.emi / inc.value * 100 : null;
  const ok = (p: Parsed) => p.status === 'ok' ? p.value : null;
  const badge = (p: Parsed, r: string, f: (n: number) => string) => p.status === 'ok' ? f(p.value) : p.status === 'empty' ? 'Not set' : r || 'Invalid';
  const pctInt = result ? result.interest / result.total * 100 : 0;
  const pctPrin = 100 - pctInt;
  const rangeOf = (val: number | null, lo: number, hi: number) => ({ min: val !== null ? Math.min(lo, val) : lo, max: val !== null ? Math.max(hi, val) : hi });
  const aR = rangeOf(ok(amt), 100000, 20000000), rR = rangeOf(ok(rate), 0, 20), tR = { min: Math.min(6, months || 6), max: MAX_MONTHS };
  const lakhs = (n: number) => n >= 10000000 ? `₹${Number((n / 10000000).toFixed(2))} Cr` : `₹${Number((n / 100000).toFixed(2))} L`;
  const field = (k: string, kind: Kind) => ({ error: parseInput(raw(k), kind).error });
  const setMonths = (m: number) => {
    setTenureDraft(null);
    putValue('tenure', roundTo(m / 12, 12));
  };
  const editMonths = (text: string) => {
    setTenureDraft(text);
    const parsed = parseInput(text, 'income');
    if (parsed.status === 'empty') putValue('tenure', '');
    else if (parsed.status === 'ok' && Number.isInteger(parsed.value) && parsed.value >= 1 && parsed.value <= MAX_MONTHS) {
      putValue('tenure', roundTo(parsed.value / 12, 12));
    }
  };

  return <Card style={styles.card}>
    <T style={styles.heading}>EMI <T variant="heading" color={palette.primary} style={styles.heading}>Amount</T></T>
    {isExample && <T variant="caption" muted style={styles.center}>Showing example assumptions (not a lender offer). Drag or type to use your own.</T>}

    <LoanSlider id="loanamount" label="Loan amount" unitHint="rupees" min={aR.min} max={aR.max} step={50000} value={ok(amt)}
      badge={badge(amt, raw('loanamount'), currency)} raw={raw('loanamount')} error={field('loanamount', 'amount').error}
      minLabel={lakhs(aR.min)} maxLabel={lakhs(aR.max)} onSlide={n => putValue('loanamount', String(n))} onRaw={t => putValue('loanamount', t)} />
    <LoanSlider id="rate" label="Interest per year" unitHint="percent per year, 0 allowed" min={rR.min} max={Math.min(MAX_RATE, rR.max)} step={0.05} value={ok(rate)}
      badge={badge(rate, raw('rate'), n => `${n}%`)} raw={raw('rate')} error={field('rate', 'rate').error}
      minLabel={`${rR.min}%`} maxLabel={`${Math.min(MAX_RATE, rR.max)}%`} onSlide={n => putValue('rate', roundTo(n, 2))} onRaw={t => putValue('rate', t)} />
    <LoanSlider id="tenure" label="Tenure (Months)" unitHint="months, between 1 and 480" min={tR.min} max={tR.max} step={1} value={ten.status === 'ok' ? months : null}
      badge={badge(ten, tenureDraft ?? raw('tenure'), () => `${months} Months`)}
      raw={tenureDraft ?? (savedTenure.status === 'ok' ? String(Math.round(savedTenure.value * 12)) : raw('tenure'))} error={ten.error}
      minLabel={`${tR.min}`} maxLabel={`${tR.max} (40 yr)`} onSlide={setMonths} onRaw={editMonths} />
    <T variant="caption" muted>12 months = 1 year. Tap any value above to type an exact amount, rate or number of months.</T>

    {anyInvalid ? <Banner tone="danger">Some entries are not valid. Fix the highlighted values to see an estimate. Nothing has been changed for you.</Banner>
      : !ready ? <View style={styles.empty}><T variant="heading" style={styles.center}>Your estimate will appear here</T>
        <T muted style={styles.center}>Set the loan amount, interest and tenure above.</T></View>
      : !result ? <Banner tone="danger">This combination cannot be calculated. Check the values.</Banner>
      : <View style={styles.result}>
        <View accessible accessibilityLabel={`Principal amount ${currency(amt.value)}, ${pctPrin.toFixed(1)} percent of total. Total interest ${currency(result.interest)}, ${pctInt.toFixed(1)} percent of total. Total paid ${currency(result.total)}.`}>
          <Donut principal={amt.value} interest={result.interest} />
        </View>
        <T muted style={styles.center}>Monthly EMI</T>
        <T testID="emi-value" style={styles.emi}>{currency(result.emi)}</T>
        <View style={styles.legend}>
          <View style={styles.flex}>
            <View style={styles.key}><View style={[styles.dot, { backgroundColor: palette.chartInterest }]} /><T variant="caption" muted>Total interest</T></View>
            <T style={styles.fig}>{currency(result.interest)}</T><T variant="caption" muted>{pctInt.toFixed(1)}%</T>
          </View>
          <View style={[styles.flex, { alignItems: 'flex-end' }]}>
            <View style={styles.key}><View style={[styles.dot, { backgroundColor: palette.chartPrincipal }]} /><T variant="caption" muted>Principal amount</T></View>
            <T style={styles.fig}>{currency(amt.value)}</T><T variant="caption" muted>{pctPrin.toFixed(1)}%</T>
          </View>
        </View>
        <T muted style={styles.center}>Total paid {currency(result.total)} over {months} monthly payments{rate.value === 0 ? ' (0% interest)' : ''}.</T>
      </View>}

    <View style={styles.explain}>
      <T variant="caption" muted>Loan amount is the money you borrow. Interest is the yearly charge by the lender. Tenure is how many monthly payments you make. The coral part of the ring is the interest added; total paid = borrowed amount + interest.</T>
    </View>

    <Pressable testID="advanced-toggle" accessibilityRole="button" accessibilityState={{ expanded: adv }} onPress={() => setAdv(a => !a)} style={styles.advBtn}>
      <T variant="label" style={styles.flex}>Advanced details</T><Icon name={adv ? 'chevron-up' : 'chevron-down'} size={18} color={palette.mutedForeground} />
    </Pressable>
    {adv && <View style={{ gap: 12 }}>
      <Field label="Monthly income (optional, ₹)" value={v.income ?? ''} onChangeText={t => putValue('income', t)} numeric placeholder="Optional" error={inc.error} testID="field-income" />
      {share !== null && <T muted>This EMI is {share.toFixed(1)}% of the monthly income you entered.</T>}
      {ready && result && <>
        <T variant="label">Compare nearby tenures</T>
        {options.map(o => {
          const r = o.r!, active = o.m === months;
          return <Pressable key={o.m} accessibilityRole="button" accessibilityState={{ selected: active }} testID={`tenure-option-${o.m}`}
            accessibilityLabel={`${fmtYears(o.m)}, EMI ${currency(r.emi)}, total interest ${currency(r.interest)}`}
            onPress={() => setMonths(o.m)} style={[styles.option, active && styles.optionOn]}>
            <View style={styles.row2}><T variant="label" style={styles.flex}>{fmtYears(o.m)}{active ? ' (selected)' : ''}</T><T variant="label">{currency(r.emi)} / mo</T></View>
            <T variant="caption" muted>Total interest {currency(r.interest)}</T>
          </Pressable>;
        })}
        <Pressable testID="years-toggle" accessibilityRole="button" onPress={() => setShowYears(s => !s)} style={styles.advBtn}>
          <T variant="label" style={styles.flex}>{showYears ? 'Hide' : 'Show'} yearly repayment breakdown</T><Icon name={showYears ? 'chevron-up' : 'chevron-down'} size={18} color={palette.mutedForeground} />
        </Pressable>
        {showYears && <ScrollView horizontal accessibilityLabel="Yearly repayment table. Scroll horizontally to see all columns."><View style={{ minWidth: 380 }}>
          <View style={styles.row}><T variant="caption" style={styles.c0}>Year</T><T variant="caption" style={styles.c}>Principal</T><T variant="caption" style={styles.c}>Interest</T><T variant="caption" style={styles.c}>Balance</T></View>
          {rows.map(r => <View key={r.year} style={styles.row}>
            <T variant="caption" style={styles.c0}>{r.year}</T><T variant="caption" style={styles.c}>{currency(r.principalPaid)}</T>
            <T variant="caption" style={styles.c}>{currency(r.interestPaid)}</T><T variant="caption" style={styles.c}>{currency(r.closing)}</T>
          </View>)}
        </View></ScrollView>}
      </>}
    </View>}
    <Disclaimer />
  </Card>;
}

const styles = StyleSheet.create({
  card: { borderRadius: 20, padding: 18, gap: 8, shadowColor: palette.primary, shadowOpacity: 0.12, shadowRadius: 18, shadowOffset: { width: 0, height: 6 }, elevation: 3 },
  heading: { fontSize: 22, lineHeight: 30, textAlign: 'center', fontWeight: '500' },
  center: { textAlign: 'center' },
  flex: { flex: 1 },
  empty: { padding: 16, gap: 6, borderRadius: 12, backgroundColor: palette.secondary },
  result: { alignItems: 'center', gap: 6, paddingTop: 8 },
  emi: { fontSize: 36, lineHeight: 44, fontWeight: '700', color: palette.primary, textAlign: 'center' },
  legend: { flexDirection: 'row', alignSelf: 'stretch', gap: 12, marginTop: 6 },
  key: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dot: { width: 10, height: 10, borderRadius: 2 },
  fig: { fontSize: 18, lineHeight: 26 },
  explain: { padding: 12, borderRadius: 12, backgroundColor: palette.secondary },
  advBtn: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 8, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: palette.border },
  option: { minHeight: 56, padding: 12, gap: 3, borderRadius: colors.radius, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.card },
  optionOn: { borderColor: palette.primary, backgroundColor: palette.secondary },
  row2: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  row: { flexDirection: 'row', gap: 4, paddingVertical: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: palette.border },
  c0: { width: 36 },
  c: { flex: 1, textAlign: 'right' },
});

import React, { useState, type ReactNode } from 'react';
import { Modal, Platform, Pressable, StyleSheet, Text, TextInput, View, type TextStyle, type StyleProp, type ViewStyle } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { useAnimatedStyle, useSharedValue, withTiming, ReduceMotion } from 'react-native-reanimated';
import { useEffect } from 'react';
import colors from '@/constants/colors';
import { disclaimer } from '@/lib/data';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useFinnest } from '@/context/FinnestContext';

const palette = colors.light;
export type FeatherIconName = React.ComponentProps<typeof Feather>['name'];
type Variant = 'body' | 'title' | 'heading' | 'caption' | 'label';
const variants: Record<Variant, TextStyle> = {
  body: { fontSize: 16, lineHeight: 24, fontFamily: Platform.OS === 'ios' ? 'System' : 'Inter_400Regular' },
  title: { fontSize: 30, lineHeight: 36, letterSpacing: -0.7, fontFamily: Platform.OS === 'ios' ? 'System' : 'Inter_600SemiBold', fontWeight: '700' },
  heading: { fontSize: 21, lineHeight: 28, letterSpacing: -0.4, fontFamily: Platform.OS === 'ios' ? 'System' : 'Inter_600SemiBold', fontWeight: '600' },
  caption: { fontSize: 12, lineHeight: 18, fontFamily: Platform.OS === 'ios' ? 'System' : 'Inter_500Medium', fontWeight: '500' },
  label: { fontSize: 15, lineHeight: 22, fontFamily: Platform.OS === 'ios' ? 'System' : 'Inter_600SemiBold', fontWeight: '600' },
};
export function T({ children, variant = 'body', muted = false, color, style, testID }: { children: ReactNode; variant?: Variant; muted?: boolean; color?: string; style?: StyleProp<TextStyle>; testID?: string }) {
  return <Text testID={testID} style={[variants[variant], { color: color ?? (muted ? palette.mutedForeground : palette.foreground) }, style]}>{children}</Text>;
}
export function Icon({ name, size = 20, color = palette.primary }: { name: FeatherIconName; size?: number; color?: string }) {
  return <Feather name={name} size={size} color={color} />;
}
function feedback() { if (Platform.OS !== 'web') void Haptics.selectionAsync().catch(() => undefined); }
export function Card({ children, soft = false, style }: { children: ReactNode; soft?: boolean; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, soft && { backgroundColor: palette.secondary, borderColor: palette.secondary }, style]}>{children}</View>;
}
export function Button({ label, onPress, variant = 'secondary', disabled = false, icon, testID }: {
  label: string; onPress: () => void; variant?: 'primary' | 'secondary' | 'quiet' | 'danger'; disabled?: boolean; icon?: FeatherIconName; testID?: string;
}) {
  const textColor = variant === 'primary' ? palette.primaryForeground : variant === 'danger' ? palette.destructive : palette.foreground;
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ disabled }} testID={testID ?? label} disabled={disabled}
    onPress={() => { feedback(); onPress(); }}
    style={({ pressed }) => [styles.button, variant === 'primary' && { backgroundColor: palette.primary, borderColor: palette.primary }, variant === 'quiet' && { borderColor: 'transparent', backgroundColor: 'transparent', paddingHorizontal: 4 }, disabled && { opacity: .4 }, pressed && { opacity: .8, transform: [{ scale: .98 }] }]}>
    {icon && <Icon name={icon} size={17} color={textColor}/>}<T variant="label" color={textColor} style={{ textAlign: 'center', flexShrink: 1 }}>{label}</T>
  </Pressable>;
}
export function Field({ label, value, onChangeText, multiline = false, numeric = false, placeholder, error, testID }: {
  label: string; value: string; onChangeText: (value: string) => void; multiline?: boolean; numeric?: boolean; placeholder?: string; error?: string; testID?: string;
}) {
  return <View style={{ gap: 7 }}><T variant="label">{label}</T><TextInput
    accessibilityLabel={label} testID={testID ?? label} value={value} onChangeText={onChangeText}
    placeholder={placeholder ?? (numeric ? 'Enter amount' : 'Enter details')} placeholderTextColor={palette.mutedForeground}
    keyboardType={numeric ? 'decimal-pad' : 'default'} multiline={multiline} textAlignVertical={multiline ? 'top' : 'center'}
    autoCapitalize={numeric ? 'none' : 'sentences'} style={[styles.input, multiline && { minHeight: 100, paddingTop: 12 }, error ? { borderColor: palette.destructive } : undefined]}/>
    {!!error && <Text accessibilityRole="alert" accessibilityLiveRegion="polite" style={{ fontSize: 13, color: palette.destructive }}>{error}</Text>}
  </View>;
}
export function Chip({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ selected }} testID={`chip-${label}`} onPress={() => { feedback(); onPress(); }}
    style={({ pressed }) => [styles.chip, selected && { backgroundColor: palette.secondary, borderColor: palette.primary }, pressed && { opacity: .75 }]}>
    {selected && <Icon name="check" size={14} color={palette.primary}/>}<T variant="caption" style={{ fontSize: 14 }} color={palette.foreground}>{label}</T>
  </Pressable>;
}
export function CheckRow({ label, checked, onToggle, description }: { label: string; checked: boolean; onToggle: () => void; description?: string }) {
  return <Pressable accessibilityRole="checkbox" accessibilityLabel={label} accessibilityState={{ checked }} testID={`check-${label}`}
    onPress={() => { feedback(); onToggle(); }} style={({ pressed }) => [styles.checkRow, pressed && { opacity: .7 }]}>
    <View style={[styles.checkbox, checked && { backgroundColor: palette.primary, borderColor: palette.primary }]}>{checked && <Icon name="check" size={15} color={palette.primaryForeground}/>}</View>
    <View style={{ flex: 1, gap: 3 }}><T variant="label">{label}</T>{!!description && <T variant="caption" muted>{description}</T>}</View>
  </Pressable>;
}
export function Accordion({ title, children, initialOpen = false }: { title: string; children: ReactNode; initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen);
  return <View style={{ borderBottomColor: palette.border, borderBottomWidth: StyleSheet.hairlineWidth }}>
    <Pressable accessibilityRole="button" accessibilityLabel={title} accessibilityState={{ expanded: open }} testID={`expand-${title}`} onPress={() => { feedback(); setOpen(o => !o); }}
      style={{ minHeight: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
      <T variant="label" style={{ flex: 1 }}>{title}</T><Icon name={open ? 'chevron-up' : 'chevron-down'} size={18} color={palette.mutedForeground}/>
    </Pressable>{open && <View style={{ gap: 12, paddingBottom: 16 }}>{children}</View>}
  </View>;
}
export function Progress({ value }: { value: number }) {
  const percent = Math.max(0, Math.min(100, Number.isFinite(value) ? value : 0));
  const progress = useSharedValue(percent);
  useEffect(() => { progress.value = withTiming(percent, { duration: 450, reduceMotion: ReduceMotion.System }); }, [percent, progress]);
  const fillStyle = useAnimatedStyle(() => ({ width: `${progress.value}%` as `${number}%` }));
  return <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: percent }} style={styles.progressTrack}><Animated.View style={[styles.progressFill, fillStyle]}/></View>;
}
export function Banner({ children, tone = 'info' }: { children: ReactNode; tone?: 'info' | 'warning' | 'danger' | 'success' }) {
  const backgroundColor = tone === 'danger' ? palette.dangerBackground : tone === 'warning' ? palette.warningBackground : palette.secondary;
  return <View accessibilityLiveRegion="polite" style={[styles.card, { backgroundColor, padding: 16 }]}>{typeof children === 'string' ? <T color={tone === 'danger' ? palette.destructive : tone === 'warning' ? palette.warningForeground : palette.primary}>{children}</T> : children}</View>;
}
export function Empty({ title, description, actionLabel, onAction }: { title: string; description: string; actionLabel?: string; onAction?: () => void }) {
  return <View style={{ alignItems: 'center', padding: 20, gap: 12 }}><Icon name="inbox" size={24}/><T variant="heading" style={{ textAlign: 'center' }}>{title}</T><T muted style={{ textAlign: 'center' }}>{description}</T>{!!actionLabel && !!onAction && <Button label={actionLabel} onPress={onAction} variant="primary"/>}</View>;
}
export function Disclaimer() { return <T variant="caption" muted style={{ paddingTop: 6 }}>{disclaimer}</T>; }
export function Sheet({ title, visible, onClose, children }: { title: string; visible: boolean; onClose: () => void; children: ReactNode }) {
  const insets = useSafeAreaInsets();
  return <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
    <View style={{ flex: 1, backgroundColor: palette.backdrop, justifyContent: 'flex-end', paddingTop: insets.top + 24 }}>
      <Pressable accessibilityLabel="Close dialog" onPress={onClose} style={StyleSheet.absoluteFill}/>
      <View accessibilityViewIsModal style={{ maxHeight: '92%', backgroundColor: palette.card, borderTopLeftRadius: 8, borderTopRightRadius: 8, overflow: 'hidden' }}>
        <View style={{ padding: 20, flexDirection: 'row', alignItems: 'center', gap: 12 }}><T variant="heading" style={{ flex: 1 }}>{title}</T><Button label="Close" icon="x" onPress={onClose} variant="quiet"/></View>
        <KeyboardAwareScrollViewCompat bottomOffset={24} keyboardShouldPersistTaps="handled" contentContainerStyle={{ gap: 16, paddingHorizontal: 20, paddingBottom: Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 0) + 20 }}>
          {children}
        </KeyboardAwareScrollViewCompat>
      </View>
    </View>
  </Modal>;
}
export function Screen({ title, eyebrow, description, children, back = true, onBack, backDisabled = false }: {
  title?: string; eyebrow?: string; description?: string; children: ReactNode;
  back?: boolean; onBack?: () => void; backDisabled?: boolean;
}) {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { storageError, ready, retryStorage } = useFinnest();
  return <View style={{ flex: 1, backgroundColor: palette.background }}>
    <KeyboardAwareScrollViewCompat style={{ flex: 1 }} bottomOffset={24} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag" contentInsetAdjustmentBehavior="never"
      contentContainerStyle={{ paddingHorizontal: 20, paddingTop: Platform.OS === 'web' ? 67 : insets.top + 12, paddingBottom: Platform.OS === 'web' ? 34 : 24, gap: 20 }}>
      {back && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        {back && <Button label="Back" icon="arrow-left" variant="quiet" disabled={backDisabled} testID="screen-back"
          onPress={onBack ?? (() => router.canGoBack() ? router.back() : router.replace('/(tabs)'))}/>}
      </View>}
      {(title || eyebrow || description) && <View style={{ gap: 8, marginBottom: 3 }}>
        {!!eyebrow && <T variant="caption" color={palette.primary} style={{ letterSpacing: 1 }}>{eyebrow}</T>}
        {!!title && <T variant="title">{title}</T>}
        {!!description && <T muted>{description}</T>}
      </View>}
      {ready && !!storageError && <Banner tone="warning"><T>{storageError}</T><Button label="Retry saving" onPress={retryStorage}/></Banner>}
      {children}
    </KeyboardAwareScrollViewCompat>
  </View>;
}
const styles = StyleSheet.create({
  card: { backgroundColor: palette.card, borderRadius: colors.radius, padding: 20, gap: 14, borderWidth: StyleSheet.hairlineWidth, borderColor: palette.border },
  button: { minHeight: 46, paddingHorizontal: 16, paddingVertical: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: colors.radius, backgroundColor: palette.card, borderWidth: 1, borderColor: palette.border },
  input: { minHeight: 48, paddingHorizontal: 13, paddingVertical: 10, fontSize: 16, color: palette.foreground, borderWidth: 1, borderColor: palette.input, borderRadius: colors.radius, backgroundColor: palette.card, fontFamily: Platform.OS === 'ios' ? 'System' : 'Inter_400Regular' },
  chip: { minHeight: 44, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 4, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.card, flexDirection: 'row', alignItems: 'center', gap: 6 },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 54, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: palette.border },
  checkbox: { height: 23, width: 23, borderRadius: 4, borderWidth: 1.5, borderColor: palette.border, alignItems: 'center', justifyContent: 'center' },
  progressTrack: { height: 7, borderRadius: 2, backgroundColor: palette.border, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 2, backgroundColor: palette.primary },
});
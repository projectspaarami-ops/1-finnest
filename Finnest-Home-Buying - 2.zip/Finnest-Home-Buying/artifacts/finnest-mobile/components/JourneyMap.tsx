import { Pressable, StyleSheet, View } from 'react-native';
import { Card, Icon, T } from '@/components/ui';
import { useFinnest } from '@/context/FinnestContext';
import { newSteps, resaleSteps } from '@/lib/data';
import colors from '@/constants/colors';

/** One map for Home and Journey, using the same saved completion state. */
export function JourneyMap({ activeStep, testIDPrefix = 'journey' }: {
  activeStep: number; testIDPrefix?: string;
}) {
  const { state, openStep } = useFinnest();
  const steps = state.propertyType === 'Resale Property' ? resaleSteps : newSteps;
  return <Card>
    <View style={styles.heading}>
      <T variant="heading" style={styles.grow}>Journey map</T>
      <T variant="caption" muted>{steps.length} steps</T>
    </View>
    {steps.map((title, index) => {
      const complete = !!state.checked[`stepdone-${index}`];
      const current = index === activeStep;
      return <Pressable key={title} accessibilityRole="button"
        accessibilityLabel={`Step ${index + 1}: ${title}${complete ? ', completed' : current ? ', current step' : ''}`}
        accessibilityState={{ selected: current }} testID={`${testIDPrefix}-step-${index}`}
        onPress={() => openStep(index)}
        style={({ pressed }) => [styles.row, index === steps.length - 1 && styles.last, pressed && { opacity: .65 }]}>
        <View style={[styles.number, (complete || current) && styles.active]}>
          {complete ? <Icon name="check" size={15} color={colors.light.primaryForeground}/>
            : <T variant="caption" color={current ? colors.light.primaryForeground : colors.light.mutedForeground}>{index + 1}</T>}
        </View>
        <T style={styles.grow} color={current ? colors.light.primary : colors.light.foreground}>{title}</T>
        <Icon name="chevron-right" size={16} color={colors.light.mutedForeground}/>
      </Pressable>;
    })}
  </Card>;
}

const styles = StyleSheet.create({
  heading: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  grow: { flex: 1 },
  row: { minHeight: 58, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.light.border },
  last: { borderBottomWidth: 0 },
  number: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.light.muted },
  active: { backgroundColor: colors.light.primary },
});
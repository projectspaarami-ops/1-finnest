import { useEffect, useRef, useState } from 'react';
import { PanResponder, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { T } from '@/components/ui';
import colors from '@/constants/colors';

const palette = colors.light;
const PAD = 16;

type Props = {
  label: string; id: string; min: number; max: number; step: number;
  value: number | null; badge: string; raw: string; error?: string; unitHint: string;
  minLabel: string; maxLabel: string; onSlide: (v: number) => void; onRaw: (t: string) => void;
};

export default function LoanSlider(p: Props) {
  const [w, setW] = useState(0);
  const [editing, setEditing] = useState(false);
  const pr = useRef(p); pr.current = p;
  const wr = useRef(0); wr.current = w;
  const start = useRef(0);
  const lastTick = useRef<number | null>(null);
  const span = Math.max(1e-9, p.max - p.min);
  const usable = Math.max(1, w - PAD * 2);
  const frac = p.value === null ? 0 : Math.min(1, Math.max(0, (p.value - p.min) / span));

  const fromX = (x: number) => {
    const q = pr.current;
    const f = Math.min(1, Math.max(0, (x - PAD) / Math.max(1, wr.current - PAD * 2)));
    const v = Math.round((q.min + f * (q.max - q.min)) / q.step) * q.step;
    return Math.min(q.max, Math.max(q.min, Number(v.toFixed(6))));
  };
  const emit = (v: number) => {
    if (lastTick.current !== v) {
      lastTick.current = v;
      if (Platform.OS !== 'web') void Haptics.selectionAsync().catch(() => undefined);
      pr.current.onSlide(v);
    }
  };
  const nudge = (dir: number, mult = 1) => {
    const q = pr.current;
    const base = q.value ?? q.min;
    emit(Math.min(q.max, Math.max(q.min, Number((base + dir * q.step * mult).toFixed(6)))));
  };
  useEffect(() => { lastTick.current = p.value; }, [p.value]);

  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: e => { start.current = e.nativeEvent.locationX; emit(fromX(start.current)); },
    onPanResponderMove: (_e, g) => emit(fromX(start.current + g.dx)),
  })).current;

  const webKeys = Platform.OS === 'web' ? ({
    onKeyDown: (e: { key: string; preventDefault: () => void }) => {
      const m: Record<string, [number, number]> = { ArrowRight: [1, 1], ArrowUp: [1, 1], ArrowLeft: [-1, 1], ArrowDown: [-1, 1], PageUp: [1, 10], PageDown: [-1, 10] };
      if (m[e.key]) { e.preventDefault(); nudge(m[e.key][0], m[e.key][1]); }
      else if (e.key === 'Home') { e.preventDefault(); emit(pr.current.min); }
      else if (e.key === 'End') { e.preventDefault(); emit(pr.current.max); }
    },
  } as object) : {};

  return <View style={styles.wrap}>
    <View style={styles.head}>
      <T style={styles.label}>{p.label}</T>
      {editing
        ? <TextInput autoFocus testID={`field-${p.id}`} accessibilityLabel={`${p.label}, ${p.unitHint}`} value={p.raw} onChangeText={p.onRaw}
          onBlur={() => setEditing(false)} onSubmitEditing={() => setEditing(false)} keyboardType="decimal-pad" returnKeyType="done"
          style={[styles.badge, styles.input, !!p.error && { borderColor: palette.destructive }]} />
        : <Pressable testID={`badge-${p.id}`} accessibilityRole="button" accessibilityLabel={`${p.label}: ${p.badge}. Tap to type an exact value`}
          onPress={() => setEditing(true)} style={styles.badge}>
          <T variant="label" color={palette.primary} style={styles.badgeText}>{p.badge}</T>
        </Pressable>}
    </View>
    <View testID={`slider-${p.id}`} accessible accessibilityRole="adjustable" accessibilityLabel={`${p.label} slider, ${p.unitHint}`}
      accessibilityValue={{ min: p.min, max: p.max, now: p.value ?? p.min, text: p.badge }}
      accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
      onAccessibilityAction={e => nudge(e.nativeEvent.actionName === 'increment' ? 1 : -1)}
      {...({ focusable: true, tabIndex: 0 } as object)} {...webKeys}
      onLayout={e => setW(e.nativeEvent.layout.width)} style={styles.touch} {...pan.panHandlers}>
      <View pointerEvents="none" style={[styles.track, { left: PAD, right: PAD }]} />
      <View pointerEvents="none" style={[styles.fill, { left: PAD, width: usable * frac }]} />
      <View pointerEvents="none" style={[styles.thumb, { left: PAD + usable * frac - 11, opacity: p.value === null ? 0.5 : 1 }]} />
    </View>
    <View style={styles.ends}><T variant="caption" muted>{p.minLabel}</T><T variant="caption" muted>{p.maxLabel}</T></View>
    {!!p.error && <T variant="caption" color={palette.destructive}>{p.error}</T>}
  </View>;
}

const styles = StyleSheet.create({
  wrap: { gap: 0 },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, minHeight: 44 },
  label: { fontSize: 15, flexShrink: 1 },
  badge: { minHeight: 44, minWidth: 96, maxWidth: 190, paddingHorizontal: 12, borderRadius: 8, backgroundColor: palette.chartPrincipal, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'transparent' },
  badgeText: { textAlign: 'center' },
  input: { color: palette.primary, fontSize: 16, fontWeight: '600', textAlign: 'center', backgroundColor: palette.card, borderColor: palette.primary },
  touch: { height: 44, justifyContent: 'center', ...(Platform.OS === 'web' ? ({ touchAction: 'none', cursor: 'pointer', userSelect: 'none' } as object) : {}) },
  track: { position: 'absolute', height: 3, borderRadius: 2, backgroundColor: palette.border },
  fill: { position: 'absolute', height: 3, borderRadius: 2, backgroundColor: palette.primary },
  thumb: { position: 'absolute', width: 22, height: 22, borderRadius: 11, backgroundColor: palette.card, borderWidth: 2.5, borderColor: palette.primary },
  ends: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 4, marginTop: -4 },
});

import { useEffect, useMemo, useState } from 'react';
import { Alert, BackHandler, Platform, Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Accordion, Banner, Button, Card, CheckRow, Chip, Empty, Field, Icon, Progress, Screen, Sheet, T, type FeatherIconName } from '@/components/ui';
import { useFinnest } from '@/context/FinnestContext';
import { disclaimer, expertTypes, newRedFlags, newSteps, resaleRedFlags, resaleSteps, type AppState } from '@/lib/data';
import colors from '@/constants/colors';
import { PropertyTypeCard } from '@/components/PropertyTypeCard';
import { JourneyMap } from '@/components/JourneyMap';

const documentItems = [
  'Identity documents',
  'Address documents',
  'Income documents',
  'Bank statements',
  'Property documents',
  'Chain of ownership',
  'Original sale deed',
  'Title documents',
  'Approved plan',
];

const aboutQuestions = [
  ['Where am I?', 'Your current place in the home-buying process.'],
  ['What have I completed?', 'Steps and checklist items you have marked complete.'],
  ['What is pending?', 'The next checklist items in your chosen journey.'],
  ['What documents do I need?', 'Items to gather, based on the journey section.'],
  ['What should I verify?', 'Prompts to support your own verification.'],
  ['Why is this important?', 'A short explanation inside the relevant checklist.'],
  ['Who can help me?', 'Expert categories you may choose to explore.'],
  ['What should I do next?', 'A suggested next action, with no pressure to purchase.'],
];

const familyOptions = ['Living alone', 'Couple', 'Family', 'Other'];
const recommendationIcons: Record<string, FeatherIconName> = {
  "Children's play area": 'smile', Garden: 'feather', 'Open space': 'sun',
  'School accessibility': 'book-open', 'Safe internal movement': 'shield',
  'Recreational facilities': 'activity', 'Lift accessibility': 'arrow-up',
  'Hospital proximity': 'plus-circle', 'Walking areas': 'map-pin',
  'Garden/open space': 'feather', 'Seating areas': 'grid',
  'Low-step/easy-access areas': 'corner-up-right', 'Public transport': 'truck',
};
const greeting = () => {
  const hour = new Date().getHours();
  return hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
};

function journeyFor(state: AppState) {
  return state.propertyType === 'Resale Property' ? resaleSteps : newSteps;
}

export function HomeScreen() {
  const { state, nav, openStep, putValue } = useFinnest();
  const journey = journeyFor(state);
  const completed = journey.reduce((total, _step, index) => total + (state.checked[`stepdone-${index}`] ? 1 : 0), 0);
  const firstIncomplete = journey.findIndex((_step, index) => !state.checked[`stepdone-${index}`]);
  const next = Math.min(journey.length - 1, firstIncomplete < 0 ? journey.length - 1 : firstIncomplete);
  const percent = journey.length ? Math.round((completed / journey.length) * 100) : 0;
  const recommendations = [
    ...(state.profile.children ? ["Children's play area", 'Garden', 'Open space', 'School accessibility', 'Safe internal movement', 'Recreational facilities'] : []),
    ...(state.profile.elderly ? ['Lift accessibility', 'Hospital proximity', 'Walking areas', 'Garden/open space', 'Seating areas', 'Low-step/easy-access areas', 'Public transport'] : []),
  ];

  return (
    <Screen back={false} eyebrow="YOUR HOME-BUYING JOURNEY" title={`${greeting()}${state.profile.name ? `, ${state.profile.name}` : ''}`} description={`A clear next step, at your pace${state.profile.city ? ` · ${state.profile.city}` : ''}.`}>
      <Card style={styles.heroCard}>
        <T variant="label" color={colors.light.primary}>YOUR JOURNEY</T>
        <T variant="heading" style={styles.heroTitle}>{state.propertyType}</T>
        <T muted>{completed} of {journey.length} steps completed</T>
        <Progress value={percent} />
        <View style={styles.row}>
          <View style={styles.progressBadge}><T variant="title">{percent}%</T></View>
          <View style={styles.grow}>
            <T variant="label">{completed === journey.length ? 'Journey complete' : 'Progress saved'}</T>
            <T variant="caption" muted>Your entries stay on this device.</T>
          </View>
        </View>
        <Button label="View your journey" variant="quiet" icon="arrow-right" onPress={() => nav('Journey')} testID="home-view-journey" />
      </Card>

      <Card soft style={styles.recommendation}>
        <T variant="label">RECOMMENDED NEXT ACTION</T>
        <T variant="heading">{journey[next]}</T>
        <T>{journey[next] === 'Verify Developer' ? 'Review the information provided and what you have independently verified.' : 'Continue through the checklist and keep your notes together.'}</T>
        <Button label="Continue" variant="primary" onPress={() => openStep(next)} icon="arrow-right" testID="home-continue" />
      </Card>

      <JourneyMap activeStep={next} testIDPrefix="home"/>

      {recommendations.length > 0 && (
        <>
          <View style={styles.sectionHead}><T variant="title">Personalized recommendations</T><T variant="caption" color={colors.light.primary}>Based on your profile</T></View>
          <Card soft>
            <T muted>Consider these during visits and verification. Your priorities remain yours.</T>
            <T variant="caption" muted>Choose one priority to focus on during your next visit. The other recommendations still apply.</T>
            <View accessibilityRole="radiogroup" accessibilityLabel="Priority for your next visit" style={styles.chips}>
              {recommendations.map(item => {
                const selected = state.values.homePriority === item;
                return <Pressable key={item} accessibilityRole="radio" accessibilityState={{ checked: selected }}
                  accessibilityLabel={item} testID={`home-priority-${item.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}
                  onPress={() => putValue('homePriority', item)}
                  style={({ pressed }) => [styles.recommendationChip, selected && { borderColor: colors.light.primary, backgroundColor: colors.light.card }, pressed && { opacity: .7 }]}>
                  <Icon name={recommendationIcons[item] ?? 'check-circle'} size={17} color={selected ? colors.light.primary : colors.light.mutedForeground}/>
                  <T variant="caption" style={{ flexShrink: 1, fontSize: 13 }} color={selected ? colors.light.primary : colors.light.foreground}>{item}</T>
                  <View style={[styles.priorityRadio, selected && { borderColor: colors.light.primary }]}>
                    {selected && <View style={styles.priorityDot}/>}
                  </View>
                </Pressable>;
              })}
            </View>
          </Card>
        </>
      )}

      <T variant="title" style={styles.sectionTitle}>Useful places to start</T>
      <View style={styles.actions}>
        <ActionCard icon="file-text" title="Documents" text="Keep track of documents to gather and review." onPress={() => nav('Documents')} />
        <ActionCard icon="users" title="Experts" text="Explore the kinds of professionals who may help." onPress={() => nav('Experts')} />
        <ActionCard icon="alert-triangle" title="Red Flags" text="Warning signs to pause and review." onPress={() => nav('Red Flags')} />
      </View>
    </Screen>
  );
}

function ActionCard({ icon, title, text, onPress }: { icon: 'file-text' | 'users' | 'alert-triangle'; title: string; text: string; onPress: () => void }) {
  return (
    <Card style={styles.actionCard}>
      <View style={styles.row}>
        <Icon name={icon} color={colors.light.primary} size={20} />
        <T variant="title" style={styles.grow}>{title}</T>
        <Button label="Open" variant="quiet" icon="chevron-right" onPress={onPress} testID={`home-action-${title.toLowerCase().replace(' ', '-')}`} />
      </View>
      <T muted>{text}</T>
    </Card>
  );
}

export function OnboardingScreen() {
  const { state, setState } = useFinnest();
  const router = useRouter();
  const [stage, setStage] = useState(1);
  const [profile, setProfile] = useState(state.profile);
  const [propertyType, setPropertyType] = useState<AppState['propertyType']>(state.propertyType);
  const [error, setError] = useState('');
  const updateProfile = <K extends keyof typeof profile>(key: K, value: typeof profile[K]) => setProfile((previous) => ({ ...previous, [key]: value }));
  const previousStage = () => { setError(''); setStage(previous => Math.max(1, previous - 1)); };
  useEffect(() => {
    if (Platform.OS !== 'android' || stage <= 1) return;
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      setError('');
      setStage(previous => Math.max(1, previous - 1));
      return true;
    });
    return () => subscription.remove();
  }, [stage]);

  const advance = () => {
    if (stage === 1) {
      setStage(2);
      return;
    }
    if (stage === 2) {
      if (!propertyType) {
        setError('Choose a property type to continue.');
        return;
      }
      setError('');
      setStage(3);
      return;
    }
    if (!profile.name.trim() || !profile.city.trim()) {
      setError('Add your name and city to continue.');
      return;
    }
    setState((current) => ({ ...current, onboarded: true, profile, propertyType }));
    router.replace('/(tabs)');
  };

  return (
    <Screen onBack={stage > 1 ? previousStage : undefined} backDisabled={stage === 1 && !router.canGoBack()}
      eyebrow={stage === 1 ? 'GAME OF HOME BUYING' : stage === 2 ? 'FIRST, YOUR JOURNEY' : 'A LITTLE ABOUT YOU'} title={stage === 1 ? "Buying a home shouldn't feel like a gamble." : stage === 2 ? 'What kind of home are you exploring?' : 'Make this journey yours.'} description={stage === 1 ? 'Finnest helps Indian home buyers navigate the home-buying process step by step. Get guided, informed and organized—while you remain the decision-maker.' : stage === 2 ? 'Choose a path. You can review your details as you go.' : 'Your answers help tailor the checklist. They stay on this device.'}>
      <Card style={styles.onboardCard}>
        {stage === 1 ? (
          <>
            <View style={styles.divider} />
            <T muted>Don't just buy a home. Follow the process.</T>
            <Button label="Start your journey" variant="primary" icon="arrow-right" onPress={advance} testID="onboarding-start" />
          </>
        ) : stage === 2 ? (
          <>
            <View accessibilityRole="radiogroup" accessibilityLabel="Property type" style={{ gap: 15 }}>
              {(['New Property', 'Resale Property'] as const).map(kind => (
                <PropertyTypeCard key={kind} kind={kind} selected={propertyType === kind}
                  onSelect={() => {
                    setPropertyType(kind);
                    setState(current => ({ ...current, propertyType: kind }));
                    setError('');
                  }}/>
              ))}
            </View>
            <View style={styles.row}>
              <Button label="Back" variant="secondary" icon="arrow-left" onPress={previousStage} />
              <Button label="Continue" variant="primary" disabled={!propertyType} icon="arrow-right" onPress={advance} testID="onboarding-continue" />
            </View>
          </>
        ) : (
          <>
            <Field label="Name" value={profile.name} onChangeText={(value) => updateProfile('name', value)} placeholder="Your name" testID="onboarding-name" />
            <Field label="City" value={profile.city} onChangeText={(value) => updateProfile('city', value)} placeholder="Your city" testID="onboarding-city" />
            <T variant="label">Family situation</T>
            <View style={styles.chips}>{familyOptions.map((option) => <Chip key={option} label={option} selected={profile.family === option} onPress={() => updateProfile('family', profile.family === option ? '' : option)} />)}</View>
            <CheckRow label="Children" checked={profile.children} onToggle={() => updateProfile('children', !profile.children)} />
            <CheckRow label="Elderly parents" checked={profile.elderly} onToggle={() => updateProfile('elderly', !profile.elderly)} />
            <CheckRow label="First-time buyer" checked={profile.firstTime} onToggle={() => updateProfile('firstTime', !profile.firstTime)} />
            <View style={styles.row}>
              <Button label="Back" variant="secondary" icon="arrow-left" onPress={previousStage} />
              <Button label="See your journey" variant="primary" icon="arrow-right" onPress={advance} testID="onboarding-finish" />
            </View>
          </>
        )}
        {!!error && <T color={colors.light.destructive}>{error}</T>}
      </Card>
      <T variant="caption" muted style={styles.disclaimer}>{disclaimer}</T>
    </Screen>
  );
}

export function DocumentsScreen() {
  const { state, toggleCheck } = useFinnest();
  const count = documentItems.filter((item) => !!state.checked[`document-${item}`]).length;
  return (
    <Screen eyebrow="YOUR DOCUMENTS" title="Documents" description="A place to track what you have gathered and what still needs review.">
      <Card>
        {documentItems.map((item) => {
          const checked = !!state.checked[`document-${item}`];
          return <CheckRow key={item} label={item} description={checked ? 'Marked as gathered' : 'Not marked yet'} checked={checked} onToggle={() => toggleCheck(`document-${item}`)} />;
        })}
      </Card>
      <Card soft>
        <T variant="label">DOCUMENT CHECKLIST</T>
        <T variant="heading">{count} of {documentItems.length}</T>
        <Progress value={(count / documentItems.length) * 100} />
        <T muted>Checklist progress only; it does not verify authenticity or completeness.</T>
        {count === 0 && <Empty title="No documents marked yet" description="Mark items as gathered to keep track of your checklist." />}
      </Card>
      <T variant="caption" muted style={styles.disclaimer}>{disclaimer}</T>
    </Screen>
  );
}

export function RedFlagsScreen() {
  const { state, toggleCheck, openExperts } = useFinnest();
  const list = state.propertyType === 'Resale Property' ? resaleRedFlags : newRedFlags;
  const flagged = list.filter((item) => state.checked[`flag-${item}`]);
  return (
    <Screen eyebrow="PAUSE AND REVIEW" title="Red Flags" description="Use these prompts to notice when you may need to pause and verify independently.">
      <Banner tone="danger">
        <T variant="label">Stop and obtain professional advice before proceeding.</T>
        <T>If you encounter a warning sign, pause and seek advice relevant to your situation.</T>
      </Banner>
      <T variant="title" style={styles.sectionTitle}>{state.propertyType === 'Resale Property' ? 'Resale property red flags' : 'New property red flags'}</T>
      <Card>
        {list.map((item) => (
          <CheckRow key={item} label={item} description={state.checked[`flag-${item}`] ? 'Noted for follow-up' : 'Not yet noted'} checked={!!state.checked[`flag-${item}`]} onToggle={() => toggleCheck(`flag-${item}`)} />
        ))}
      </Card>
      <Card>
        <T variant="title">Action to take</T>
        <T muted>Pause. Keep a written record of what raised concern, ask for documents or clarification, and seek independent professional advice before deciding how to proceed.</T>
        {flagged.length > 0 && (
          <View style={styles.flagAdvice}>
            <Banner tone="warning"><T>You noted {flagged.length} warning {flagged.length === 1 ? 'sign' : 'signs'}. Consider discussing the concern with an independent property professional before deciding how to proceed.</T></Banner>
            <Button label="Talk to a Property Lawyer" variant="secondary" icon="arrow-right" onPress={() => openExperts('Property Lawyer')} testID="red-flags-property-lawyer" />
          </View>
        )}
      </Card>
    </Screen>
  );
}

export function AboutScreen() {
  return (
    <Screen eyebrow="ABOUT FINNEST" title="A steadier way to move forward" description="Game of Home Buying">
      <Card>
        <T variant="label" color={colors.light.primary}>OUR PHILOSOPHY</T>
        <T variant="heading">Don't just buy a home. Follow the process.</T>
        <T muted>Finnest is a guided decision-support and checklist product. It helps you navigate the process step by step, while you remain the decision-maker.</T>
        <View style={styles.philosophy}>
          <Icon name="shield" color={colors.light.primary} size={22} />
          <T variant="title">Review. Verify. Decide.</T>
          <T muted>No pressure to purchase. Your pace, your decision.</T>
        </View>
      </Card>
      <T variant="title" style={styles.sectionTitle}>Eight questions, answered by every step</T>
      <Card>
        {aboutQuestions.map(([question, answer]) => (
          <Accordion key={question} title={question}>
            <T muted>{answer}</T>
          </Accordion>
        ))}
      </Card>
      <Banner tone="info"><T variant="label">Disclaimer</T><T>{disclaimer}</T></Banner>
    </Screen>
  );
}

const expertIcons: Record<string, FeatherIconName> = {
  'Property Lawyer': 'briefcase',
  'Chartered Accountant': 'dollar-sign',
  'Home Loan Advisor': 'credit-card',
  'Property Consultant': 'home',
  'Architect / Technical Expert': 'tool',
  'Interior Expert': 'layout',
  'Valuation Expert': 'bar-chart-2',
  Astrologer: 'compass',
  'Vastu Expert': 'map',
};

export function ExpertsScreen() {
  const { state, setState, nav, setToast } = useFinnest();
  const [query, setQuery] = useState('');
  const [profile, setProfile] = useState<string | null>(null);
  const [requestCategory, setRequestCategory] = useState<string | null>(null);
  const [form, setForm] = useState({ name: state.profile.name, contact: '', message: '' });
  const [error, setError] = useState('');
  const filtered = useMemo(() => expertTypes.filter((expert) => expert.toLowerCase().includes(query.trim().toLowerCase())), [query]);
  const closeRequest = () => { setRequestCategory(null); setError(''); };
  const saveRequest = () => {
    if (!form.name.trim() || !form.contact.trim()) {
      setError('Add your name and a phone number or email to save this request.');
      return;
    }
    const category = requestCategory;
    if (!category) return;
    const savedAt = new Date().toLocaleString('en-IN');
    setState((current) => ({
      ...current,
      requests: [...current.requests, { id: Date.now(), category, name: form.name.trim(), contact: form.contact.trim(), message: form.message.trim(), savedAt }],
    }));
    closeRequest();
    setForm((current) => ({ ...current, contact: '', message: '' }));
    setToast('Request saved on this device only. It has not been sent.');
  };
  const removeRequest = (id: number, category: string) => Alert.alert(
    'Remove saved request?',
    `Remove the saved request for ${category}?`,
    [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => setState((current) => ({ ...current, requests: current.requests.filter((item) => item.id !== id) })) },
    ],
  );

  return (
    <Screen eyebrow="PROFESSIONAL SUPPORT" title="Experts" description="Explore professional categories that may be relevant to your home-buying process. Provider listings are not available in this prototype.">
      <Field label="Find a category" value={query} onChangeText={setQuery} placeholder="Search expert categories" testID="expert-search" />
      {filtered.length ? filtered.map((expert) => {
        const active = state.expertCategory === expert;
        return (
          <Card key={expert} style={active ? styles.activeExpert : undefined}>
            <View style={styles.row}>
              <Icon name={expertIcons[expert] ?? 'users'} color={colors.light.primary} size={21} />
              <T variant="label" color={active ? colors.light.primary : colors.light.mutedForeground}>{active ? 'Suggested for this step' : 'Category'}</T>
            </View>
            <T variant="title" style={styles.expertTitle}>{expert}</T>
            <T muted>Consider whether independent professional support may help. Finnest makes no claims about individual professionals.</T>
            <View style={styles.row}>
              <Button
                label={active ? 'Selected for this step' : 'Select category'}
                variant={active ? 'quiet' : 'secondary'}
                icon={active ? 'check' : 'plus'}
                onPress={() => setState((current) => ({ ...current, expertCategory: expert }))}
                testID={`expert-select-${expertTypes.indexOf(expert)}`}
              />
              <Button label="View Profile" variant="secondary" onPress={() => setProfile(expert)} testID={`expert-profile-${expertTypes.indexOf(expert)}`} />
              <Button label="Contact Expert" onPress={() => { setRequestCategory(expert); setError(''); }} testID={`expert-contact-${expertTypes.indexOf(expert)}`} />
            </View>
          </Card>
        );
      }) : (
        <Empty title="No matching categories" description="Try another search or clear the search text." actionLabel="Clear search" onAction={() => setQuery('')} />
      )}

      <T variant="title" style={styles.sectionTitle}>Your saved requests</T>
      {state.requests.length === 0 ? (
        <Empty title="No requests saved" description="Requests are kept only on this device and are never sent anywhere." />
      ) : (
        <Card>
          <T variant="caption" muted>Stored on this device</T>
          {state.requests.map((item) => (
            <View key={item.id} style={styles.requestRow}>
              <View style={styles.grow}>
                <T variant="label">{item.category}</T>
                <T variant="caption" muted>{item.name} · {item.contact} · {item.savedAt}</T>
                {!!item.message && <T>{item.message}</T>}
              </View>
              <Button label="Remove" variant="danger" icon="trash-2" onPress={() => removeRequest(item.id, item.category)} testID={`remove-request-${item.id}`} />
            </View>
          ))}
        </Card>
      )}
      <Card soft>
        <T variant="label">Contextual support</T>
        <T muted>Expert suggestions appear inside the journey where a professional may help.</T>
        <Button label="Return to your journey" variant="quiet" icon="arrow-right" onPress={() => nav('Journey')} />
      </Card>

      <Sheet title={`${profile ?? ''} profiles`} visible={!!profile} onClose={() => setProfile(null)}>
        <Banner tone="warning"><T variant="label">Prototype data</T></Banner>
        <Empty
          title="No provider profiles available"
          description="This prototype has no backend, so there are no real provider profiles to show. A profile would list name, profession, years of experience, property transaction experience, expertise, location, credentials and services offered, supplied and verified by the provider."
        />
        <View style={styles.row}>
          <Button label="Close" variant="secondary" onPress={() => setProfile(null)} />
          <Button label="Save a request instead" onPress={() => { const selected = profile; setProfile(null); if (selected) setRequestCategory(selected); }} />
        </View>
      </Sheet>

      <Sheet title={`Contact: ${requestCategory ?? ''}`} visible={!!requestCategory} onClose={closeRequest}>
        <Banner tone="warning"><T>Prototype with no backend. Saving this only stores a note on this device. Nothing is sent to any expert.</T></Banner>
        <Field label="Your name" value={form.name} onChangeText={(name) => setForm((current) => ({ ...current, name }))} testID="expert-request-name" />
        <Field label="Phone or email" value={form.contact} onChangeText={(contact) => setForm((current) => ({ ...current, contact }))} placeholder="Your phone number or email" testID="expert-request-contact" />
        <Field label="What do you need help with? (optional)" value={form.message} onChangeText={(message) => setForm((current) => ({ ...current, message }))} multiline testID="expert-request-message" />
        {!!error && <T color={colors.light.destructive}>{error}</T>}
        <View style={styles.row}>
          <Button label="Cancel" variant="secondary" onPress={closeRequest} />
          <Button label="Save request on this device" variant="primary" onPress={saveRequest} testID="expert-request-save" />
        </View>
      </Sheet>
    </Screen>
  );
}

const styles = StyleSheet.create({
  heroCard: { gap: 12 },
  heroTitle: { marginTop: 4 },
  row: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 10 },
  grow: { flex: 1, minWidth: 140 },
  progressBadge: { width: 66, height: 66, borderRadius: 33, borderWidth: 5, borderColor: colors.light.primary, alignItems: 'center', justifyContent: 'center' },
  recommendation: { gap: 10 },
  sectionHead: { marginTop: 22, marginBottom: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 },
  sectionTitle: { marginTop: 22, marginBottom: 8 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  recommendationChip: { minHeight: 44, maxWidth: '100%', flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 12, paddingVertical: 9, backgroundColor: colors.light.accent, borderRadius: 999, borderWidth: 1, borderColor: colors.light.border },
  priorityRadio: { width: 18, height: 18, borderRadius: 9, borderWidth: 1.5, borderColor: colors.light.mutedForeground, justifyContent: 'center', alignItems: 'center' },
  priorityDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.light.primary },
  actions: { gap: 12 },
  actionCard: { gap: 10 },
  onboardCard: { gap: 15 },
  divider: { height: 1, backgroundColor: colors.light.border, marginVertical: 8 },
  disclaimer: { marginTop: 18 },
  flagAdvice: { gap: 12, marginTop: 12 },
  philosophy: { padding: 15, borderRadius: 4, backgroundColor: colors.light.accent, gap: 7, marginTop: 8 },
  expertTitle: { marginTop: 10 },
  activeExpert: { borderColor: colors.light.primary, borderWidth: 2 },
  requestRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.light.border },
});

import { useMemo, useState, type ReactNode } from 'react';
import { Alert, Linking, Platform, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useFinnest } from '@/context/FinnestContext';
import {
  anyError, configurations, currency, disclaimer, legalItems, locations,
  loanFromEmi, newSteps, num, numError, resaleSteps, residentQs, siteItems,
  type Project,
} from '@/lib/data';
import { Accordion, Banner, Button, Card, CheckRow, Chip, Disclaimer, Empty, Field, Icon, Progress, Screen, Sheet, T } from '@/components/ui';
import colors from '@/constants/colors';
import LoanCalculator from '@/components/LoanCalculator';
import { JourneyMap } from '@/components/JourneyMap';

type Kind = 'new' | 'resale';
type ProjectDraft = Omit<Project, 'id' | 'kind'>;

const blankDraft: ProjectDraft = {
  name: '', developer: '', location: '', configuration: '', area: '', price: '', possession: '', rera: '',
  amenities: '', parking: '', maintenance: '', connectivity: '', schoolHealthcare: '', reputation: '',
  constructionQuality: '', customerFeedback: '', legalStatus: '', financialStability: '', trackRecord: '', infrastructure: '',
};
const projectFields: [keyof ProjectDraft, string][] = [
  ['name', 'Project name'], ['developer', 'Developer'], ['location', 'Location'], ['configuration', 'Configuration'],
  ['area', 'Carpet area (sq ft)'], ['price', 'Total price (₹)'], ['possession', 'Possession'], ['rera', 'RERA'],
  ['amenities', 'Amenities'], ['parking', 'Parking'], ['maintenance', 'Maintenance'], ['connectivity', 'Connectivity'],
  ['schoolHealthcare', 'School / healthcare'], ['reputation', 'Developer reputation'], ['constructionQuality', 'Construction quality'],
  ['customerFeedback', 'Customer feedback'], ['legalStatus', 'Legal status'], ['financialStability', 'Financial stability'],
  ['trackRecord', 'Track record'], ['infrastructure', 'Government infrastructure proximity'],
];
const lenderRows = ['Lender name', 'Interest rate', 'Fixed/floating', 'Processing fee', 'Prepayment terms', 'Tenure', 'EMI', 'Total interest', 'Other charges'];
const developerItems = ['Experience and reputation', 'RERA registration', 'Legal history', 'Land ownership', 'Government approvals', 'Title-clear land'];
const finalItems = ['Lawyer due diligence completed', 'CA/tax consultation completed where required', 'Loan sanction verified', 'Agreement reviewed', 'Promised specifications documented', 'Payment schedule understood', 'Possession terms understood', 'Cancellation/refund provisions understood', 'Additional charges understood', 'Original/required documents verified', 'Occupancy Certificate confirmed where applicable'];
const resaleSections: { title: string; body: string; items: string[] }[] = [
  { title: 'Define requirements', body: 'Note your budget, location and configuration priorities.', items: ['Budget considered', 'Loan eligibility considered', 'Location priorities noted', 'Configuration preferences noted'] },
  { title: 'Shortlist property', body: 'Keep the details you have gathered together for each property.', items: ['Property details recorded', 'Asking price recorded', 'Seller details recorded', 'Documents requested'] },
  { title: 'Visit property', body: 'Review physical condition and the surroundings in person.', items: ['Physical condition reviewed', 'Water and electricity checked', 'Ventilation and natural light reviewed', 'Approach and surroundings reviewed'] },
  { title: 'Verify seller', body: 'Confirm seller identity and authority with professional guidance.', items: ['Seller identity reviewed', 'Authority to sell discussed', 'Details cross-checked with documents'] },
  { title: 'Verify title & ownership', body: 'Review ownership documents with a qualified property lawyer.', items: ['Ownership documents requested', 'Ownership details reviewed by lawyer', 'Title-related questions addressed'] },
  { title: 'Verify society documents', body: 'Request relevant society records and clarify what applies to the property.', items: ['Society documents requested', 'Transfer process clarified', 'Relevant approvals discussed'] },
  { title: 'Verify financial dues', body: 'Clarify any outstanding dues and charges with the relevant parties.', items: ['Society dues clarified', 'Utility dues clarified', 'Other charges recorded'] },
  { title: 'Check existing loan', body: 'If a loan exists, clarify the process and documents with the lender and lawyer.', items: ['Existing loan status clarified', 'Lender process discussed', 'Release documents clarified'] },
  { title: 'Legal due diligence', body: 'Seek independent legal review for your situation.', items: ['Lawyer appointed', 'Documents reviewed', 'Open questions resolved with lawyer'] },
  { title: 'Agreement', body: 'Have the agreement reviewed and understand the terms before signing.', items: ['Agreement reviewed', 'Payment terms understood', 'Conditions and timelines understood'] },
  { title: 'Home loan', body: 'Discuss eligibility and loan terms directly with lenders.', items: ['Loan terms compared', 'Costs understood', 'Sanction details reviewed'] },
  { title: 'Registration & transfer', body: 'Clarify registration and handover steps with the relevant professionals.', items: ['Registration process confirmed', 'Transfer requirements confirmed', 'Handover and keys planned'] },
];

function Copy({ children, muted = false }: { children: ReactNode; muted?: boolean }) {
  return <T variant="body" muted={muted} style={styles.copy}>{children}</T>;
}

function CheckList({ items, prefix, explanation }: { items: string[]; prefix: string; explanation?: string }) {
  const { state, toggleCheck } = useFinnest();
  return <View style={styles.checkList}>{items.map(item => (
    <CheckRow key={item} label={item} description={explanation} checked={!!state.checked[`${prefix}-${item}`]} onToggle={() => toggleCheck(`${prefix}-${item}`)} />
  ))}</View>;
}

function NumberField({ label, field, placeholder = 'Enter amount' }: { label: string; field: string; placeholder?: string }) {
  const { state, putValue } = useFinnest();
  const error = numError(state.values[field]);
  return <Field label={label} value={state.values[field] || ''} onChangeText={value => putValue(field, value)} numeric placeholder={placeholder} error={error} testID={`field-${field}`} />;
}

function MetricCard({ label, value }: { label: string; value: string }) {
  return <Card soft><T variant="caption" muted>{label}</T><T variant="heading" style={styles.metric}>{value}</T></Card>;
}

function Requirements() {
  const { state, togglePick, openExperts } = useFinnest();
  const chargeKeys = ['stamp', 'registration', 'gst', 'brokerage', 'interior', 'other'];
  const invalid = anyError(state, ['down', 'eligibility', 'affordable', 'bRate', 'bTenure', ...chargeKeys]);
  const down = num(state, 'down');
  const eligibility = num(state, 'eligibility');
  const emiLoan = loanFromEmi(num(state, 'affordable'), num(state, 'bRate'), num(state, 'bTenure'));
  const loanCandidates = [eligibility, emiLoan].filter(value => value > 0);
  const budget = down + (loanCandidates.length ? Math.min(...loanCandidates) : 0);
  const charges = chargeKeys.reduce((sum, key) => sum + num(state, key), 0);
  const allocation = budget - charges;
  const locationGroup = state.propertyType === 'Resale Property' ? 'resaleLocations' : 'location';
  const picked = state.selected[locationGroup] || [];
  const config = state.selected.config || [];
  const factors = state.selected.factors || [];
  return <View style={styles.stack}>
    <Card>
      <T variant="label" color={colors.light.primary}>1A · SET YOUR BUDGET</T>
      <T variant="title" style={styles.cardTitle}>A budget that feels comfortable</T>
      <Copy muted>Enter estimates to understand what you may wish to plan around. This is a planning tool, not a lending decision.</Copy>
      <View style={styles.formGrid}>
        <NumberField label="Down payment" field="down" />
        <NumberField label="Home loan eligibility (your own figure, if you have one)" field="eligibility" />
        <NumberField label="EMI affordability: comfortable EMI per month" field="affordable" />
        <NumberField label="Assumed interest rate % (for EMI affordability)" field="bRate" placeholder="Your assumption" />
        <NumberField label="Assumed tenure in years" field="bTenure" placeholder="Your assumption" />
      </View>
      <T variant="heading" style={styles.subheading}>Other costs to set aside</T>
      <View style={styles.formGrid}>{[
        ['Stamp duty', 'stamp'], ['Registration charges', 'registration'], ['GST where applicable', 'gst'],
        ['Brokerage', 'brokerage'], ['Interior/furnishing', 'interior'], ['Maintenance and other charges', 'other'],
      ].map(([label, key]) => <NumberField key={key} label={label} field={key} />)}</View>
      {invalid ? <Banner tone="danger">One or more values are negative or not valid numbers. Correct the highlighted fields to see results.</Banner> : <View style={styles.metrics}>
        <MetricCard label="Loan supported by your comfortable EMI (illustrative, independent of eligibility)" value={emiLoan > 0 ? currency(emiLoan) : 'Enter EMI, rate and tenure'} />
        <MetricCard label="Eligibility figure you entered (not a lender approval)" value={eligibility > 0 ? currency(eligibility) : 'Not entered'} />
        <MetricCard label="ESTIMATED COMFORTABLE BUDGET" value={currency(budget)} />
        <MetricCard label="AVAILABLE FOR PROPERTY PRICE" value={budget > 0 ? (allocation >= 0 ? currency(allocation) : `Short by ${currency(-allocation)}`) : '₹0'} />
      </View>}
      <Copy muted>Down payment plus the lower of your entered eligibility and the EMI-supported loan. Budget minus {currency(charges)} of entered charges is available for the property price.</Copy>
      <Copy muted>Eligibility is decided by lenders. This estimate does not guarantee any loan.</Copy>
      <Accordion title="Golden Rule"><Copy>The detailed Golden Rule text was not included in the supplied material, so none is shown here. Use your own comfort level and consult a qualified financial professional before deciding.</Copy></Accordion>
      <Disclaimer />
    </Card>
    <Card>
      <T variant="label" color={colors.light.primary}>1B · CHOOSE YOUR LOCATION</T>
      <T variant="title" style={styles.cardTitle}>What matters in a location?</T>
      <Copy muted>Choose as many priorities as you like. They are ranked in the order you select them.</Copy>
      <View style={styles.chips}>{locations.map(location => <Chip key={location} label={location} selected={picked.includes(location)} onPress={() => togglePick(locationGroup, location)} />)}</View>
      <T variant="heading" style={styles.subheading}>Your location priorities</T>
      {picked.length ? picked.map((location, index) => <T key={location} variant="body" style={styles.ranked}>{index + 1}.  {location}</T>) : <Copy muted>Select priorities to create your ranked list.</Copy>}
    </Card>
    <Card>
      <T variant="label" color={colors.light.primary}>1C · DECIDE CONFIGURATION</T>
      <T variant="title" style={styles.cardTitle}>What kind of home fits?</T>
      <View style={styles.chips}>{configurations.map(item => <Chip key={item} label={item} selected={config.includes(item)} onPress={() => togglePick('config', item)} />)}</View>
      <Copy muted>Select the configurations you want to consider. Detailed configuration guidance was not included in the supplied material.</Copy>
      <T variant="heading" style={styles.subheading}>Additional factors</T>
      <View style={styles.chips}>{['Parking', 'Amenities'].map(item => <Chip key={item} label={item} selected={factors.includes(item)} onPress={() => togglePick('factors', item)} />)}</View>
      <Accordion title="Optional add-on: Vastu">
        <Banner tone="warning">Importance ★★★★☆</Banner>
        <Copy>Vastu is an optional add-on and not part of the main journey. Detailed Vastu content was not included in the supplied material. A Vastu Expert category is available under Experts.</Copy>
        <Button label="Explore Vastu Expert category" icon="arrow-right" onPress={() => openExperts('Vastu Expert')} />
      </Accordion>
    </Card>
  </View>;
}

function DeveloperStep() {
  const { state, toggleCheck, openExperts } = useFinnest();
  const verified = developerItems.filter(item => state.checked[`independent-${item}`]).length;
  return <Card>
    <T variant="label" color={colors.light.primary}>DEVELOPER CHECKLIST</T>
    <T variant="title" style={styles.cardTitle}>Verify the developer</T>
    <Copy muted>Keep what the developer told you separate from what you have independently checked.</Copy>
    <Banner tone="warning">INFORMATION PROVIDED BY DEVELOPER{"\n"}Claims and documents shared by the seller side.</Banner>
    <Banner tone="info">INDEPENDENTLY VERIFIED{"\n"}Checked by you or a professional through independent sources.</Banner>
    {developerItems.map(item => {
      const independent = !!state.checked[`independent-${item}`];
      return <Card key={item} style={styles.innerCard}>
        <View style={styles.inline}>
          <T variant="heading" style={styles.flex}>{item}</T>
          <T variant="caption" color={independent ? colors.light.primary : colors.light.mutedForeground}>{independent ? 'Verified' : 'Verification pending'}</T>
        </View>
        <CheckRow label="Information provided by developer" checked={!!state.checked[`developer-provided-${item}`]} onToggle={() => toggleCheck(`developer-provided-${item}`)} />
        <CheckRow label="Independently verified" checked={independent} onToggle={() => toggleCheck(`independent-${item}`)} />
      </Card>;
    })}
    <Copy muted>{verified} of {developerItems.length} independently verified</Copy>
    <Banner tone="warning">Avoid{"\n"}Treating developer-provided information as independently verified.</Banner>
    <Button label="Need help verifying this? Find a Property Lawyer" onPress={() => openExperts('Property Lawyer')} icon="arrow-right" />
  </Card>;
}

function perSqFt(project: ProjectDraft) {
  const area = Number(project.area), price = Number(project.price);
  return area > 0 && price > 0 && Number.isFinite(area) && Number.isFinite(price) ? `${currency(price / area)} / sq ft` : 'Add carpet area and price';
}
function displayValue(project: ProjectDraft, field: keyof ProjectDraft) {
  const value = project[field];
  if (!value) return 'Not entered';
  if (field === 'price') return currency(Number(value));
  if (field === 'area') return `${value} sq ft`;
  return value;
}

function ProjectManager({ kind }: { kind: Kind }) {
  const { state, setState, togglePick, setToast } = useFinnest();
  const projects = state.projects.filter(project => (project.kind ?? 'new') === kind);
  const comparisonKey = `compare-${kind}`;
  const compared = projects.filter(project => (state.selected[comparisonKey] || []).includes(String(project.id)));
  const [openId, setOpenId] = useState<number | null>(null);
  const [dialog, setDialog] = useState<{ id: number | null; draft: ProjectDraft } | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [pendingRemoval, setPendingRemoval] = useState<Project | null>(null);
  const noun = kind === 'new' ? 'project' : 'property';

  const save = () => {
    if (!dialog) return;
    const draft = dialog.draft, nextErrors: string[] = [];
    if (!draft.name.trim()) nextErrors.push(`Enter a ${noun} name.`);
    if (numError(draft.area)) nextErrors.push('Carpet area must be a non-negative number.');
    if (numError(draft.price)) nextErrors.push('Total price must be a non-negative number.');
    if (nextErrors.length) { setErrors(nextErrors); return; }
    if (dialog.id === null && projects.length >= 5) { setErrors(['You can add up to 5.']); return; }
    if (dialog.id === null) setState(current => ({ ...current, projects: [...current.projects, { ...draft, id: Date.now(), kind }] }));
    else setState(current => ({ ...current, projects: current.projects.map(project => project.id === dialog.id ? { ...project, ...draft } : project) }));
    setToast(dialog.id === null ? 'Saved to your shortlist' : 'Details updated');
    setDialog(null);
    setErrors([]);
  };
  const applyRemove = (project: Project) => {
    setState(current => ({
      ...current,
      projects: current.projects.filter(item => item.id !== project.id),
      selected: { ...current.selected, [comparisonKey]: (current.selected[comparisonKey] || []).filter(id => id !== String(project.id)) },
    }));
    setPendingRemoval(null);
    setToast('Removed from your shortlist');
  };
  const remove = (project: Project) => {
    if (Platform.OS === 'web') { setPendingRemoval(project); return; }
    Alert.alert(`Remove ${project.name}?`, 'Remove this from your shortlist?', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Remove', style: 'destructive', onPress: () => applyRemove(project) },
  ]);
  };
  const edit = (project: Project) => {
    const { id, kind: _kind, ...draft } = project;
    setDialog({ id, draft });
    setErrors([]);
  };

  return <View style={styles.stack}>
    <Card>
      <View style={styles.inline}>
        <View style={styles.flex}>
          <T variant="title" style={styles.cardTitle}>{kind === 'new' ? 'Shortlist projects' : 'Shortlist property'}</T>
          <Copy muted>Add up to 5 to compare. {projects.length} of 5 added.</Copy>
        </View>
        <Button label={`Add ${noun}`} icon="plus" disabled={projects.length >= 5} onPress={() => { setDialog({ id: null, draft: { ...blankDraft } }); setErrors([]); }} />
      </View>
      {projects.length === 0 ? <Empty title={`No ${noun}s added yet`} description="Add details you have gathered yourself. Finnest does not provide or verify listings." /> : projects.map(project => (
        <Card key={project.id} style={styles.innerCard}>
          <View style={styles.inline}>
            <View style={styles.flex}>
              <T variant="heading">{project.name}</T>
              <Copy muted>{project.developer || 'Developer not entered'} · {project.location || 'Location not entered'}</Copy>
            </View>
            <CheckRow label="Compare" checked={(state.selected[comparisonKey] || []).includes(String(project.id))} onToggle={() => togglePick(comparisonKey, String(project.id))} />
          </View>
          <Copy>{displayValue(project, 'configuration')} · {displayValue(project, 'area')} · {displayValue(project, 'price')} · {perSqFt(project)}</Copy>
          <View style={styles.actions}>
            <Button label={openId === project.id ? 'Hide full details' : 'View full details'} variant="quiet" icon="chevron-down" onPress={() => setOpenId(openId === project.id ? null : project.id)} />
            <Button label="Edit" variant="quiet" icon="edit-2" onPress={() => edit(project)} />
            <Button label="Remove" variant="danger" icon="trash-2" onPress={() => remove(project)} />
          </View>
          {openId === project.id && <View style={styles.detailsGrid}>
            <View><T variant="caption">Price per sq ft</T><T>{perSqFt(project)}</T></View>
            {projectFields.filter(([field]) => !['name', 'price', 'area'].includes(field)).map(([field, label]) => <View key={field}><T variant="caption">{label}</T><T>{displayValue(project, field)}</T></View>)}
          </View>}
        </Card>
      ))}
      <T variant="caption" muted>All details are entered by you. Finnest has not verified them.</T>
    </Card>
    <Card>
      <T variant="title" style={styles.cardTitle}>Compare</T>
      {projects.length < 2 ? <Copy muted>Add at least two to compare them side by side.</Copy> : compared.length < 2 ? <Copy muted>Tick Compare on two or more to see them side by side.</Copy> : (
        <ScrollView horizontal showsHorizontalScrollIndicator contentContainerStyle={styles.tableContent}>
          <View>
            <View style={styles.tableRow}><T variant="label" style={styles.tableLabel}>Detail</T>{compared.map(project => <T key={project.id} variant="label" style={styles.tableCell}>{project.name}</T>)}</View>
            {projectFields.filter(([field]) => field !== 'name').map(([field, label]) => <View key={field} style={styles.tableRow}><T variant="caption" style={styles.tableLabel}>{label}</T>{compared.map(project => <T key={project.id} style={styles.tableCell}>{displayValue(project, field)}</T>)}</View>)}
            <View style={styles.tableRow}><T variant="caption" style={styles.tableLabel}>Price per sq ft</T>{compared.map(project => <T key={project.id} style={styles.tableCell}>{perSqFt(project)}</T>)}</View>
          </View>
        </ScrollView>
      )}
    </Card>
    <Sheet title={dialog?.id === null ? `Add ${noun}` : `Edit ${noun}`} visible={!!dialog} onClose={() => setDialog(null)}>
    {dialog && <>
        <Copy muted>Only enter what you have gathered. Leave anything else blank.</Copy>
        {projectFields.map(([field, label]) => <Field key={field} label={label} value={dialog.draft[field]} onChangeText={value => setDialog({ ...dialog, draft: { ...dialog.draft, [field]: value } })} numeric={field === 'area' || field === 'price'} testID={`project-${field}`} />)}
        {errors.map(error => <Banner key={error} tone="danger">{error}</Banner>)}
        <View style={styles.actions}>
          <Button label="Cancel" variant="secondary" onPress={() => setDialog(null)} />
          <Button label="Save details" variant="primary" onPress={save} />
        </View>
      </>}
    </Sheet>
    <Sheet title="Remove from shortlist?" visible={!!pendingRemoval} onClose={() => setPendingRemoval(null)}>
      <Copy>Remove {pendingRemoval?.name} and its details from your shortlist? This cannot be undone.</Copy>
      <Button label="Cancel" onPress={() => setPendingRemoval(null)}/>
      <Button label="Remove" variant="danger" onPress={() => { if (pendingRemoval) applyRemove(pendingRemoval); }}/>
    </Sheet>
  </View>;
}

function ResidentFeedback() {
  const { state, putValue, putNote, setState, openStep } = useFinnest();
  const projects = state.projects.filter(project => (project.kind ?? 'new') === 'new');
  const projectId = projects.find(project => String(project.id) === state.values.residentProject)?.id ?? projects[0]?.id;
  const answers = residentQs.map((_, index) => state.selected[`res-${projectId}-${index}`]?.[0]);
  const tally = (answer: string) => answers.filter(value => value === answer).length;
  return <Card>
    <T variant="label" color={colors.light.primary}>RESIDENT FEEDBACK</T>
    <T variant="title" style={styles.cardTitle}>Talk to 8–10 residents</T>
    <Copy muted>Record what residents tell you, one shortlisted project at a time. These are your own notes, not verified ratings.</Copy>
    {projectId === undefined ? <Empty title="No shortlisted projects" description="Add a project in Shortlist Projects to record resident feedback for it." actionLabel="Go to Shortlist Projects" onAction={() => openStep(2)} /> : <>
      <T variant="label">Project</T>
      <View style={styles.chips}>{projects.map(project => <Chip key={project.id} label={project.name} selected={project.id === projectId} onPress={() => putValue('residentProject', String(project.id))} />)}</View>
      <View style={styles.stack}>{residentQs.map((question, index) => {
        const key = `res-${projectId}-${index}`;
        return <View key={key} style={styles.question}>
          <T variant="label">{question}</T>
          <View style={styles.chips}>{['Yes', 'No', 'Not sure'].map(answer => <Chip key={answer} label={answer} selected={answers[index] === answer} onPress={() => setState(current => ({ ...current, selected: { ...current.selected, [key]: current.selected[key]?.[0] === answer ? [] : [answer] } }))} />)}</View>
          <Field label={`Notes for: ${question}`} value={state.notes[key] || ''} onChangeText={value => putNote(key, value)} placeholder="Notes (optional)" />
        </View>;
      })}</View>
      <Card soft><T variant="label">Resident feedback summary</T><Copy muted>{answers.filter(Boolean).length} of {residentQs.length} answered · Yes {tally('Yes')} · No {tally('No')} · Not sure {tally('Not sure')}</Copy></Card>
    </>}
  </Card>;
}

function SiteVisit() {
  const { state, putNote } = useFinnest();
  const done = siteItems.filter(item => state.checked[`site-${item}`]).length;
  return <View style={styles.stack}>
    <Card>
      <T variant="label" color={colors.light.primary}>SITE VISIT CHECKLIST</T>
      <T variant="title" style={styles.cardTitle}>What to observe during a visit</T>
      <Copy muted>Tap each item once you have reviewed it. Leave notes while details are fresh.</Copy>
      <Progress value={done / siteItems.length * 100} />
      <Copy muted>{done} / {siteItems.length} checked</Copy>
      <CheckList items={siteItems} prefix="site" />
      <Field label="Visit notes" value={state.notes.site || ''} onChangeText={value => putNote('site', value)} multiline placeholder="Add your observations…" />
    </Card>
    <ResidentFeedback />
  </View>;
}

function LenderTable() {
  const { state, putValue } = useFinnest();
  return <Card>
    <T variant="title" style={styles.cardTitle}>Lender comparison</T>
    <Copy muted>No lender names, offers or rates are supplied. Enter terms you receive directly from lenders.</Copy>
    <ScrollView horizontal showsHorizontalScrollIndicator contentContainerStyle={styles.tableContent}>
      <View>
        <View style={styles.tableRow}><T variant="label" style={styles.tableLabel}>Compare</T>{['1', '2', '3'].map(option => <T key={option} variant="label" style={styles.tableCell}>Option {option}</T>)}</View>
        {lenderRows.map(row => <View key={row} style={styles.tableRow}>
          <T variant="caption" style={styles.tableLabel}>{row}</T>
          {['1', '2', '3'].map(option => <View key={option} style={styles.lenderField}><Field label={`${row}, option ${option}`} value={state.values[`loancomp-${row}-${option}`] || ''} onChangeText={value => putValue(`loancomp-${row}-${option}`, value)} placeholder="Add details" testID={`loancomp-${row}-${option}`} /></View>)}
        </View>)}
      </View>
    </ScrollView>
  </Card>;
}

function LoanDocs() {
  return <Card><T variant="title" style={styles.cardTitle}>Typical documents required</T><CheckList prefix="loan-doc" items={['Identity documents', 'Address documents', 'Income documents', 'Bank statements', 'Property documents']} /><T variant="caption" muted>Requirements vary. Confirm directly with your lender.</T></Card>;
}

function LoanStep() {
  return <View style={styles.stack}><LoanCalculator /><LenderTable /><LoanDocs /></View>;
}

function ReraAction() {
  const { state, putValue } = useFinnest();
  const [linkError, setLinkError] = useState('');
  const url = (state.values.reraUrl || '').trim();
  let valid = false;
  try { valid = new URL(url).protocol === 'https:'; } catch { valid = false; }
  const open = async () => {
    if (!valid) return;
    try { await Linking.openURL(url); setLinkError(''); }
    catch { setLinkError('Unable to open the address. Check the URL and try again.'); }
  };
  return <Card>
    <T variant="title" style={styles.cardTitle}>RERA verification</T>
    <Copy muted>Find your state's official RERA portal yourself, then paste its https address below. The link is provided by you and is not verified by Finnest.</Copy>
    <Field label="Official state RERA portal URL (https)" value={state.values.reraUrl || ''} onChangeText={value => putValue('reraUrl', value)} placeholder="https://" error={url.length > 0 && !valid ? 'Enter a valid https:// address.' : undefined} testID="rera-url" />
    <Button label="Open portal in a new tab" icon="external-link" variant={valid ? 'primary' : 'secondary'} disabled={!valid} onPress={open} />
    {!!linkError && <Banner tone="danger">{linkError}</Banner>}
  </Card>;
}

function LegalStep() {
  const { state, toggleCheck, putNote, expanded, setExpanded, openExperts } = useFinnest();
  return <View style={styles.stack}>
    <Card soft>
      <T variant="title" style={styles.cardTitle}>Hire the Right Property Lawyer</T>
      <Copy muted>Consider seeking independent legal advice for your circumstances.</Copy>
      <Button label="Find a Property Lawyer" icon="arrow-right" variant="primary" onPress={() => openExperts('Property Lawyer')} />
    </Card>
    <Card>
      <T variant="title" style={styles.cardTitle}>Legal due diligence</T>
      <Copy muted>A checklist to discuss with a qualified professional.</Copy>
      {legalItems.map(([item, why, verify]) => {
        const open = !!expanded[`legal-${item}`], done = !!state.checked[`legal-${item}`];
        return <View key={item} style={styles.legalItem}>
          <View style={styles.inline}>
            <CheckRow label={item} description={done ? 'Reviewed' : 'Verification pending'} checked={done} onToggle={() => toggleCheck(`legal-${item}`)} />
            <Pressable accessibilityRole="button" accessibilityLabel={`Details for ${item}`} onPress={() => setExpanded({ ...expanded, [`legal-${item}`]: !open })} style={styles.iconButton}><Icon name="chevron-down" /></Pressable>
          </View>
          {open && <View style={styles.legalDetails}>
            <T variant="label">Why it matters</T><Copy>{why}</Copy>
            <T variant="label">What to verify</T><Copy>{verify}</Copy>
            <Field label="Notes" value={state.notes[`legal-${item}`] || ''} onChangeText={value => putNote(`legal-${item}`, value)} multiline placeholder="Optional notes" />
            <Button label="Need help verifying this? Find a Property Lawyer" variant="quiet" icon="arrow-right" onPress={() => openExperts('Property Lawyer')} />
          </View>}
        </View>;
      })}
    </Card>
    <ReraAction />
    <Disclaimer />
  </View>;
}

function TrueCost() {
  const { state } = useFinnest();
  const items: [string, string][] = [['Property price', 'tcprice'], ['Taxes', 'tctax'], ['Stamp duty', 'tcstamp'], ['Registration', 'tcreg'], ['Parking', 'tcparking'], ['Maintenance deposit', 'tcmaint'], ['Society charges', 'tcsociety'], ['Legal fees', 'tclawyer'], ['Loan processing', 'tcprocessing'], ['Interiors', 'tcinteriors'], ['Other charges', 'tcother']];
  const invalid = anyError(state, items.map(([, key]) => key));
  const total = items.reduce((sum, [, key]) => sum + num(state, key), 0);
  return <View style={styles.stack}>
    <Card>
      <T variant="label" color={colors.light.primary}>TRUE-COST CALCULATOR</T>
      <T variant="title" style={styles.cardTitle}>Look beyond the listed price</T>
      <Copy muted>Enter costs you have been quoted or estimated. Values are your inputs, not verified amounts.</Copy>
      <View style={styles.formGrid}>{items.map(([label, key]) => <NumberField key={key} label={label} field={key} />)}</View>
      {invalid ? <Banner tone="danger">One or more values are negative or not valid numbers. Correct them to see the total.</Banner> : <MetricCard label="ESTIMATED TOTAL COST" value={currency(total)} />}
    </Card>
    <LenderTable />
    <Disclaimer />
  </View>;
}

function FinalStep() {
  const { state } = useFinnest();
  const done = finalItems.filter(item => state.checked[`final-${item}`]).length;
  const percent = Math.round(done / finalItems.length * 100);
  return <View style={styles.stack}>
    <Card>
      <T variant="label" color={colors.light.primary}>FINAL VERIFICATION</T>
      <T variant="title" style={styles.cardTitle}>Review before you decide</T>
      <Copy muted>A checklist for your own review. A ticked item is not a professional verification.</Copy>
      <CheckList items={finalItems} prefix="final" />
    </Card>
    <Card>
      <View style={styles.inline}><T variant="heading" style={styles.flex}>Completion</T><T variant="heading" color={colors.light.primary}>{percent}%</T></View>
      <Progress value={percent} />
      <Copy muted>{done} of {finalItems.length} items reviewed</Copy>
      {done < finalItems.length && <Copy muted>Some items are still pending. Take the time you need.</Copy>}
    </Card>
    {done === finalItems.length && <Banner tone="success">Ready to proceed?{"\n"}You have reviewed every item. The decision remains yours; consult the professionals relevant to your situation before deciding.</Banner>}
    <Disclaimer />
  </View>;
}

function ResaleDetail({ step }: { step: number }) {
  const { state, putNote, openExperts } = useFinnest();
  const section = resaleSections[step];
  return <View style={styles.stack}>
    {step === 0 && <Requirements />}
    {step === 1 && <ProjectManager kind="resale" />}
    {step === 8 && <Card soft>
      <T variant="title" style={styles.cardTitle}>Hire the Right Property Lawyer</T>
      <Button label="Find a Property Lawyer" icon="arrow-right" variant="primary" onPress={() => openExperts('Property Lawyer')} />
    </Card>}
    <Card>
      <T variant="label" color={colors.light.primary}>RESALE CHECKLIST</T>
      <T variant="title" style={styles.cardTitle}>{section.title}</T>
      <Copy muted>{section.body}</Copy>
      <CheckList items={section.items} prefix={`resale-${step}`} />
      <Field label="Notes" value={state.notes[`resale-${step}`] || ''} onChangeText={value => putNote(`resale-${step}`, value)} multiline placeholder="Record details and questions…" />
    </Card>
    {step === 2 && <Card soft>
      <T variant="heading">Physical condition</T>
      <Copy>For technical questions, consider consulting a suitably qualified professional.</Copy>
      <Button label="Find an Architect / Technical Expert" variant="quiet" icon="arrow-right" onPress={() => openExperts('Architect / Technical Expert')} />
    </Card>}
    {step === 8 && <ReraAction />}
    {step === 10 && <LoanStep />}
    {[4, 5, 6, 7, 8, 9, 10, 11].includes(step) && <Disclaimer />}
  </View>;
}

function NewDetail({ step }: { step: number }) {
  if (step === 0) return <Requirements />;
  if (step === 1) return <DeveloperStep />;
  if (step === 2) return <ProjectManager kind="new" />;
  if (step === 3) return <SiteVisit />;
  if (step === 4) return <LoanStep />;
  if (step === 5) return <LegalStep />;
  if (step === 6) return <TrueCost />;
  return <FinalStep />;
}

export default function JourneyScreen() {
  const { state, openStep, toggleCheck } = useFinnest();
  const resale = state.propertyType === 'Resale Property';
  const journey = resale ? resaleSteps : newSteps;
  const step = Math.max(0, Math.min(state.step, journey.length - 1));
  const done = !!state.checked[`stepdone-${step}`];
  const subheading = journey[step];
  const aside = resale
    ? step === 10 ? { label: 'Need help comparing loans?', action: 'Talk to a Home Loan Advisor', category: 'Home Loan Advisor' } : step === 8 || step === 4 ? { label: 'Need help verifying this?', action: 'Find a Property Lawyer', category: 'Property Lawyer' } : null
    : step === 4 ? { label: 'Need help comparing loans?', action: 'Talk to a Home Loan Advisor', category: 'Home Loan Advisor' } : step === 5 ? { label: 'Need help verifying this?', action: 'Find a Property Lawyer', category: 'Property Lawyer' } : null;
  const { openExperts } = useFinnest();
  const stepContent = useMemo(() => resale ? <ResaleDetail step={step} /> : <NewDetail step={step} />, [resale, step]);
  return <Screen
    title={subheading}
    eyebrow={`${resale ? 'RESALE PROPERTY' : 'NEW PROPERTY'} · STEP ${step + 1} OF ${journey.length}`}
    description={step === 0 ? 'Set out what matters to you before you compare options.' : 'Work through what applies to your situation. Notes save automatically.'}
    back
    onBack={step > 0 ? () => openStep(step - 1) : undefined}
  >
    <View style={styles.progressBlock}><Progress value={(step + 1) / journey.length * 100} /></View>
    <View style={styles.stack}>
      {stepContent}
      <View style={styles.navigation}>
        <Button label="Previous" icon="arrow-left" variant="secondary" disabled={step === 0} onPress={() => openStep(Math.max(0, step - 1))} />
        <View style={styles.actions}>
          <Button label={done ? 'Completed' : 'Mark step complete'} icon={done ? 'check' : undefined} variant={done ? 'secondary' : 'primary'} onPress={() => toggleCheck(`stepdone-${step}`)} />
          {step < journey.length - 1 && <Button label="Next step" icon="arrow-right" variant="primary" onPress={() => openStep(step + 1)} />}
        </View>
      </View>
      <View style={styles.saved}><Icon name="shield" size={15} color={colors.light.mutedForeground} /><T variant="caption" muted>Your progress is saved on this device.</T></View>
      <JourneyMap activeStep={step}/>
      {aside && <Card soft>
        <T variant="heading">{aside.label}</T>
        <Copy muted>Explore the relevant category. Finnest does not verify individual providers.</Copy>
        <Button label={aside.action} icon="arrow-right" variant="primary" onPress={() => openExperts(aside.category)} />
      </Card>}
      <Disclaimer />
    </View>
  </Screen>;
}

const styles = StyleSheet.create({
  stack: { gap: 14 },
  copy: { marginTop: 5, marginBottom: 9 },
  cardTitle: { marginTop: 7, marginBottom: 8 },
  subheading: { marginTop: 18, marginBottom: 9 },
  formGrid: { gap: 12, marginTop: 10 },
  metrics: { gap: 10, marginVertical: 12 },
  metric: { marginTop: 6 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginVertical: 10 },
  ranked: { paddingVertical: 4 },
  checkList: { marginVertical: 5 },
  innerCard: { marginTop: 12, padding: 14 },
  inline: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  flex: { flex: 1 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 7, marginVertical: 8 },
  detailsGrid: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.light.border, paddingTop: 12, gap: 10 },
  tableContent: { paddingRight: 12 },
  tableRow: { flexDirection: 'row', alignItems: 'center', minHeight: 52, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.light.border },
  tableLabel: { width: 150, paddingHorizontal: 9 },
  tableCell: { width: 170, paddingHorizontal: 9 },
  lenderField: { width: 185, paddingHorizontal: 6, paddingVertical: 4 },
  question: { paddingVertical: 11, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.light.border },
  legalItem: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.light.border },
  legalDetails: { paddingHorizontal: 5, paddingBottom: 14 },
  iconButton: { padding: 12 },
  progressBlock: { marginBottom: 14 },
  navigation: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginTop: 8 },
  saved: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 8 },
});
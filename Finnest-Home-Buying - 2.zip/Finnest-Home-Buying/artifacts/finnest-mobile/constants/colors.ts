/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#333333',
    tint: '#E3324A',

    // Core surfaces
    background: '#FFFFFF',
    foreground: '#333333',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#333333',

    // Primary action color (buttons, links, active states)
    primary: '#E3324A',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#F5F5F5',
    secondaryForeground: '#333333',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#F5F5F5',
    mutedForeground: '#787676',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#F5F5F5',
    accentForeground: '#333333',

    // Destructive actions (delete, error states)
    destructive: '#D92D20',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#E2E2E2',
    input: '#E2E2E2',
    success: '#333333',
    warning: '#F59E0B',
    warningBackground: '#FFF7E7',
    warningForeground: '#8A4B08',
    dangerBackground: '#FEF0EE',
    chartInterest: '#E3324A',
    chartPrincipal: '#FFE1E6',
    backdrop: 'rgba(17,17,17,0.35)',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 4,
};

export default colors;

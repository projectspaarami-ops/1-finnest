import type { Dispatch, SetStateAction } from 'react';

export type Screen = 'Home' | 'Journey' | 'Experts' | 'About' | 'Documents' | 'Red Flags';
export type Profile = { name: string; city: string; family: string; children: boolean; elderly: boolean; firstTime: boolean };
export type Project = {
  id: number; kind: 'new' | 'resale';
  name: string; developer: string; location: string; configuration: string; area: string; price: string;
  possession: string; rera: string; amenities: string; parking: string; maintenance: string; connectivity: string;
  schoolHealthcare: string; reputation: string; constructionQuality: string; customerFeedback: string;
  legalStatus: string; financialStability: string; trackRecord: string; infrastructure: string;
};
export type ExpertRequest = { id: number; category: string; name: string; contact: string; message: string; savedAt: string };
export type AppState = {
  onboarded: boolean; propertyType: 'New Property' | 'Resale Property' | '';
  profile: Profile; activeScreen: Screen; step: number;
  checked: Record<string, boolean>; values: Record<string, string>; selected: Record<string, string[]>;
  notes: Record<string, string>; projects: Project[]; expertCategory: string; requests: ExpertRequest[];
};
export type Ctx = {
  state: AppState; setState: Dispatch<SetStateAction<AppState>>;
  toggleCheck: (k: string) => void; putValue: (k: string, v: string) => void; putNote: (k: string, v: string) => void;
  togglePick: (g: string, v: string) => void; openExperts: (category: string) => void; openStep: (i: number) => void;
  setToast: (s: string) => void; expanded: Record<string, boolean>; setExpanded: Dispatch<SetStateAction<Record<string, boolean>>>;
};
export const blankProfile: Profile = { name: '', city: '', family: '', children: false, elderly: false, firstTime: false };
export const initialState: AppState = {
  onboarded: false, propertyType: '', profile: blankProfile, activeScreen: 'Home', step: 0,
  checked: {}, values: {}, selected: {}, notes: {}, projects: [], expertCategory: '', requests: [],
};
export const storageKey = 'finnest-native-v1';
export const newSteps = [
  'Define Your Requirements', 'Verify Developer', 'Shortlist Projects', 'Site Visit',
  'Home Loan', 'Legal Due Diligence', 'Financial Due Diligence', 'Final Verification',
];
export const resaleSteps = [
  'Define requirements', 'Shortlist property', 'Visit property', 'Verify seller',
  'Verify title & ownership', 'Verify society documents', 'Verify financial dues', 'Check existing loan',
  'Legal due diligence', 'Agreement', 'Home loan', 'Registration & transfer',
];
export const locations = ['Office accessibility', 'School', 'Healthcare', 'Public transport', "Parents' convenience", 'Shopping', 'Future appreciation', 'Peaceful environment', 'Connectivity'];
export const configurations = ['1 BHK', '2 BHK', '3 BHK', 'Villas / Duplexes'];
export const siteItems = ['Actual carpet area', 'Natural light', 'Ventilation', 'Noise', 'Water supply', 'Power backup', 'Parking', 'Lift capacity', 'Fire safety', 'Open spaces', 'Garden', "Children's play area", 'Senior citizen facilities', 'Security', 'Construction quality', 'Approach road', 'Surrounding development'];
export const residentQs = ['Are you satisfied with the developer?', 'Was possession delivered as promised?', 'Were there unexpected/hidden costs?', 'How is the construction quality holding up?', 'How does society management function?', 'Are there water/electricity issues?', 'How responsive is the developer?', 'Are there ongoing maintenance problems?', 'Would you recommend this project?'];
export const legalItems = [
  ['Chain of ownership', 'Review the ownership history with a property lawyer.', 'Ask the lawyer to review the relevant chain documents.'],
  ['Original sale deed', 'The sale deed records a transfer of ownership.', 'Confirm the original and supporting records with your lawyer.'],
  ['Title documents', 'Understand the title position before proceeding.', 'Have a qualified property lawyer review the documents.'],
  ['Encumbrance check', 'Check for recorded claims or interests as advised by counsel.', 'Ask a property lawyer how to conduct and interpret this check.'],
  ['Approved plan', 'Compare the available plan with the property details.', 'Confirm approvals with the relevant authority or your lawyer.'],
  ['RERA registration', 'Check the project registration where applicable.', 'Use the official state RERA portal and verify details independently.'],
  ['RERA disclosures', 'Review disclosures made for the project where applicable.', 'Compare the disclosures with documents and seek professional advice.'],
];
export const newRedFlags = ['Seller/builder pressure', 'Verbal promises', 'Refusal of independent verification', 'Missing RERA', 'Non-escrow payments', 'Unclear land title'];
export const resaleRedFlags = ['Seller pressure to decide quickly', 'Ownership details that do not match documents', 'Refusal to share relevant records', 'Unclear society dues', 'Existing loan details not clarified', 'Requests to proceed before independent review'];
export const expertTypes = ['Property Lawyer', 'Chartered Accountant', 'Home Loan Advisor', 'Property Consultant', 'Architect / Technical Expert', 'Interior Expert', 'Valuation Expert', 'Astrologer', 'Vastu Expert'];
export const disclaimer = 'This app provides general guidance. It is not a substitute for professional legal, financial or tax advice.';
export function currency(n: number) {
  if (!Number.isFinite(n) || n <= 0) return '₹0';
  return `₹${Math.round(n).toLocaleString('en-IN')}`;
}
export function numError(raw: string | undefined): string {
  if (raw === undefined || raw.trim() === '') return '';
  const n = Number(raw);
  if (!Number.isFinite(n)) return 'Enter a valid number.';
  if (n < 0) return 'Negative values are not accepted.';
  return '';
}
export function num(state: AppState, key: string) {
  const raw = state.values[key];
  return numError(raw) ? 0 : Number(raw || 0);
}
export function anyError(state: AppState, keys: string[]) { return keys.some(k => numError(state.values[k])); }
export function emiFor(principal: number, annualRate: number, years: number) {
  const months = years * 12;
  if (principal <= 0 || months <= 0) return 0;
  const rate = annualRate / 1200;
  if (rate === 0) return principal / months;
  // Equivalent to the original formula, without overflow on long tenures.
  return principal * rate / (1 - Math.pow(1 + rate, -months));
}
export function loanFromEmi(emi: number, annualRate: number, years: number) {
  const months = years * 12;
  if (emi <= 0 || months <= 0) return 0;
  const rate = annualRate / 1200;
  return rate === 0 ? emi * months : emi * (1 - Math.pow(1 + rate, -months)) / rate;
}
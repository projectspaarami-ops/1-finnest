export const MAX_MONTHS = 480;
export const MAX_AMOUNT = 1_000_000_000;
export const MAX_RATE = 30;
export type Parsed = { status: 'empty' | 'invalid' | 'ok'; value: number; error: string };
export type Kind = 'amount' | 'rate' | 'tenure' | 'income';

export function parseInput(raw: string | undefined, kind: Kind): Parsed {
  const t = (raw ?? '').trim();
  if (t === '') return { status: 'empty', value: 0, error: '' };
  const bad = (error: string): Parsed => ({ status: 'invalid', value: 0, error });
  if (!/^\d*\.?\d*$/.test(t) || t === '.') return bad('Enter a valid non-negative number.');
  const n = Number(t);
  if (!Number.isFinite(n)) return bad('Enter a valid number.');
  if (kind === 'amount') {
    if (n <= 0) return bad('Enter an amount greater than zero.');
    if (n > MAX_AMOUNT) return bad('Amounts above ₹100 crore are not supported.');
  } else if (kind === 'income') {
    if (n > MAX_AMOUNT) return bad('Enter a smaller amount.');
  } else if (kind === 'rate') {
    if (n > MAX_RATE) return bad('Rates above 30% a year are not supported.');
  } else {
    const months = n * 12;
    if (months < 1 - 1e-9) return bad('Tenure must be at least 1 month.');
    if (months > MAX_MONTHS + 1e-9) return bad('Tenure can be at most 40 years.');
    if (Math.abs(months - Math.round(months)) > 1e-9) return bad('Tenure must be a whole number of months (e.g. 2.5 years = 30 months).');
  }
  return { status: 'ok', value: n, error: '' };
}

export type Result = { emi: number; total: number; interest: number; months: number };
export function compute(principal: number, annualRate: number, months: number): Result | null {
  if (![principal, annualRate, months].every(Number.isFinite) || principal <= 0 || principal > MAX_AMOUNT || annualRate < 0 || annualRate > MAX_RATE || !Number.isInteger(months) || months < 1 || months > MAX_MONTHS) return null;
  const r = annualRate / 1200;
  const emi = r === 0 ? principal / months : principal * r / -Math.expm1(-months * Math.log1p(r));
  const total = emi * months;
  if (!Number.isFinite(emi) || !Number.isFinite(total)) return null;
  return { emi, total, interest: Math.max(0, total - principal), months };
}

export type YearRow = { year: number; principalPaid: number; interestPaid: number; closing: number };
export function yearlyBreakdown(principal: number, annualRate: number, months: number): YearRow[] {
  const res = compute(principal, annualRate, months);
  if (!res) return [];
  const r = annualRate / 1200;
  let bal = principal;
  const rows: YearRow[] = [];
  for (let m = 1; m <= months; m++) {
    const interest = bal * r;
    const princ = m === months ? bal : res.emi - interest;
    bal = Math.max(0, bal - princ);
    const y = Math.ceil(m / 12);
    if (!rows[y - 1]) rows[y - 1] = { year: y, principalPaid: 0, interestPaid: 0, closing: 0 };
    rows[y - 1].principalPaid += princ;
    rows[y - 1].interestPaid += interest;
    rows[y - 1].closing = bal;
  }
  return rows;
}

export function nearbyTenures(months: number): number[] {
  const set = new Set<number>();
  for (const d of [-60, -24, 0, 24, 60]) {
    const m = months + d;
    if (m >= 12 && m <= MAX_MONTHS) set.add(m);
  }
  set.add(months);
  return [...set].sort((a, b) => a - b);
}
export const fmtYears = (months: number) => {
  const y = Math.floor(months / 12), m = months % 12;
  return `${y ? `${y} yr` : ''}${y && m ? ' ' : ''}${m ? `${m} mo` : ''}`;
};
export const roundTo = (n: number, dp: number) => String(Number(n.toFixed(dp)));

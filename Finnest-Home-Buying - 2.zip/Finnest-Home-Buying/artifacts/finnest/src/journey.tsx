import { useState, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, BadgeCheck, Building2, Check, CheckCircle2, ChevronDown, ExternalLink, Pencil, ShieldCheck, Trash2 } from 'lucide-react';
import {
  Accordion, ErrorNote, Field, Metric, Modal, NumField, PageHead, anyError, configurations, currency, disclaimer,
  emiFor, legalItems, loanFromEmi, locations, num, numError, residentQs, siteItems,
  type Ctx, type Project,
} from '@/shared';
import { resaleSteps } from '@/shared';

type Kind = 'new' | 'resale';

function Disclaimer() { return <p className="disclaimer">{disclaimer}</p>; }

function CheckList({ ctx, items, prefix, explanation }: { ctx: Ctx; items: string[]; prefix: string; explanation?: string }) {
  return <div className="surface">{items.map(item => <label key={item} className="check-row"><input className="check-control" type="checkbox" checked={!!ctx.state.checked[`${prefix}-${item}`]} onChange={() => ctx.toggleCheck(`${prefix}-${item}`)}/><span><strong>{item}</strong>{explanation && <span className="small muted" style={{ display: 'block' }}>{explanation}</span>}</span></label>)}</div>;
}

function ContextExpert({ ctx, label, action, category }: { ctx: Ctx; label: string; action: string; category: string }) {
  return <div className="soft-surface"><h3>{label}</h3><p className="small muted">Explore the relevant category. Finnest does not verify individual providers.</p><button className="btn btn-primary" onClick={() => ctx.openExperts(category)}>{action} <ArrowRight size={15}/></button></div>;
}

/* ---------- Requirements ---------- */
function BudgetSection({ ctx }: { ctx: Ctx }) {
  const { state, putValue } = ctx;
  const chargeKeys = ['stamp', 'registration', 'gst', 'brokerage', 'interior', 'other'];
  const keys = ['down', 'eligibility', 'affordable', 'bRate', 'bTenure', ...chargeKeys];
  const invalid = anyError(state, keys);
  const down = num(state, 'down'), eligibility = num(state, 'eligibility');
  const emiLoan = loanFromEmi(num(state, 'affordable'), num(state, 'bRate'), num(state, 'bTenure'));
  const loanCandidates = [eligibility, emiLoan].filter(v => v > 0);
  const loanBasis = loanCandidates.length ? Math.min(...loanCandidates) : 0;
  const budget = down + loanBasis;
  const charges = chargeKeys.reduce((a, k) => a + num(state, k), 0);
  const allocation = budget - charges;
  return <div className="surface"><div className="eyebrow">1A · SET YOUR BUDGET</div><h2 style={{ marginTop: 8 }}>A budget that feels comfortable</h2>
    <p className="small muted">Enter estimates to understand what you may wish to plan around. This is a planning tool, not a lending decision.</p>
    <div className="field-grid">
      <NumField label="Down payment" k="down" state={state} putValue={putValue}/>
      <NumField label="Home loan eligibility (your own figure, if you have one)" k="eligibility" state={state} putValue={putValue}/>
      <NumField label="EMI affordability: comfortable EMI per month" k="affordable" state={state} putValue={putValue}/>
      <NumField label="Assumed interest rate % (for EMI affordability)" k="bRate" state={state} putValue={putValue} placeholder="Your assumption"/>
      <NumField label="Assumed tenure in years" k="bTenure" state={state} putValue={putValue} placeholder="Your assumption"/>
    </div>
    <h3 style={{ marginTop: 22 }}>Other costs to set aside</h3>
    <div className="field-grid">
      <NumField label="Stamp duty" k="stamp" state={state} putValue={putValue}/>
      <NumField label="Registration charges" k="registration" state={state} putValue={putValue}/>
      <NumField label="GST where applicable" k="gst" state={state} putValue={putValue}/>
      <NumField label="Brokerage" k="brokerage" state={state} putValue={putValue}/>
      <NumField label="Interior/furnishing" k="interior" state={state} putValue={putValue}/>
      <NumField label="Maintenance and other charges" k="other" state={state} putValue={putValue}/>
    </div>
    {invalid ? <ErrorNote>One or more values are negative or not valid numbers. Correct the highlighted fields to see results.</ErrorNote> :
      <div className="grid two-col" style={{ marginTop: 18 }}>
        <Metric label="Loan supported by your comfortable EMI (illustrative, independent of eligibility)" value={emiLoan > 0 ? currency(emiLoan) : 'Enter EMI, rate and tenure'}/>
        <Metric label="Eligibility figure you entered (not a lender approval)" value={eligibility > 0 ? currency(eligibility) : 'Not entered'}/>
        <div className="soft-surface"><div className="eyebrow">ESTIMATED COMFORTABLE BUDGET</div><motion.h2 key={budget} initial={{ opacity: 0.4, y: 4 }} animate={{ opacity: 1, y: 0 }} style={{ margin: '7px 0 0' }}>{currency(budget)}</motion.h2><p className="small muted" style={{ margin: '5px 0 0' }}>Down payment plus the lower of your entered eligibility and the EMI-supported loan.</p></div>
        <div className="soft-surface"><div className="eyebrow">AVAILABLE FOR PROPERTY PRICE</div><motion.h2 key={allocation} initial={{ opacity: 0.4, y: 4 }} animate={{ opacity: 1, y: 0 }} style={{ margin: '7px 0 0' }}>{budget > 0 ? (allocation >= 0 ? currency(allocation) : `Short by ${currency(-allocation)}`) : '₹0'}</motion.h2><p className="small muted" style={{ margin: '5px 0 0' }}>Budget minus {currency(charges)} of entered charges.</p></div>
      </div>}
    <p className="small muted" style={{ marginTop: 14 }}>Eligibility is decided by lenders. This estimate does not guarantee any loan.</p>
    <div className="divider"/>
    <Accordion title="Golden Rule" open={!!ctx.expanded.golden} toggle={() => ctx.setExpanded({ ...ctx.expanded, golden: !ctx.expanded.golden })}><p>The detailed Golden Rule text was not included in the supplied material, so none is shown here. Use your own comfort level and consult a qualified financial professional before deciding.</p></Accordion>
    <p className="disclaimer" style={{ marginTop: 15 }}>{disclaimer}</p>
  </div>;
}

function LocationPicker({ ctx, group }: { ctx: Ctx; group: string }) {
  const picked = ctx.state.selected[group] || [];
  return <div className="surface"><div className="eyebrow">1B · CHOOSE YOUR LOCATION</div><h2 style={{ marginTop: 8 }}>What matters in a location?</h2>
    <p className="small muted">Choose as many priorities as you like. They are ranked in the order you select them.</p>
    <div className="pill-select">{locations.map(l => <button key={l} aria-pressed={picked.includes(l)} className={`pill ${picked.includes(l) ? 'selected' : ''}`} onClick={() => ctx.togglePick(group, l)}>{picked.includes(l) && <Check size={14}/>} {l}</button>)}</div>
    <div className="divider"/><h3>Your location priorities</h3>
    {picked.length ? <ol className="small" style={{ paddingLeft: 22, margin: 0 }}>{picked.map(l => <motion.li layout key={l} style={{ padding: '4px 0' }}>{l}</motion.li>)}</ol> : <p className="small muted">Select priorities to create your ranked list.</p>}
  </div>;
}

function ConfigSection({ ctx }: { ctx: Ctx }) {
  const { state, togglePick } = ctx;
  const config = state.selected.config || [], factors = state.selected.factors || [];
  return <div className="surface"><div className="eyebrow">1C · DECIDE CONFIGURATION</div><h2 style={{ marginTop: 8 }}>What kind of home fits?</h2>
    <div className="pill-select">{configurations.map(c => <button key={c} aria-pressed={config.includes(c)} className={`pill ${config.includes(c) ? 'selected' : ''}`} onClick={() => togglePick('config', c)}>{config.includes(c) && <Check size={14}/>} {c}</button>)}</div>
    <p className="small muted" style={{ marginTop: 15 }}>Select the configurations you want to consider. Detailed configuration guidance was not included in the supplied material.</p>
    <h3>Additional factors</h3>
    <div className="pill-select">{['Parking', 'Amenities'].map(c => <button key={c} aria-pressed={factors.includes(c)} className={`pill ${factors.includes(c) ? 'selected' : ''}`} onClick={() => togglePick('factors', c)}>{factors.includes(c) && <Check size={14}/>} {c}</button>)}</div>
    <Accordion title="Optional add-on: Vastu" open={!!ctx.expanded.vastu} toggle={() => ctx.setExpanded({ ...ctx.expanded, vastu: !ctx.expanded.vastu })}>
      <span className="badge badge-amber">Importance ★★★★☆</span>
      <p style={{ marginTop: 10 }}>Vastu is an optional add-on and not part of the main journey. Detailed Vastu content was not included in the supplied material. A Vastu Expert category is available under Experts.</p>
      <button className="btn" onClick={() => ctx.openExperts('Vastu Expert')}>Explore Vastu Expert category <ArrowRight size={15}/></button>
    </Accordion>
  </div>;
}

/* ---------- Developer ---------- */
function DeveloperStep({ ctx }: { ctx: Ctx }) {
  const items = ['Experience and reputation', 'RERA registration', 'Legal history', 'Land ownership', 'Government approvals', 'Title-clear land'];
  const verified = items.filter(i => ctx.state.checked[`independent-${i}`]).length;
  return <div className="surface"><div className="eyebrow">DEVELOPER CHECKLIST</div><h2 style={{ marginTop: 8 }}>Verify the developer</h2>
    <p className="small muted">Keep what the developer told you separate from what you have independently checked.</p>
    <div className="grid two-col" style={{ marginBottom: 14 }}><div className="callout warning-callout"><strong>INFORMATION PROVIDED BY DEVELOPER</strong><div className="small">Claims and documents shared by the seller side.</div></div><div className="callout"><strong>INDEPENDENTLY VERIFIED</strong><div className="small">Checked by you or a professional through independent sources.</div></div></div>
    <div className="grid two-col">{items.map(item => { const ind = !!ctx.state.checked[`independent-${item}`]; return <div className="surface" key={item} style={{ padding: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}><h3>{item}</h3>{ind ? <span className="badge badge-green"><BadgeCheck size={13}/> Verified</span> : <span className="badge badge-amber">Verification pending</span>}</div>
      <label className="check-row"><input className="check-control" type="checkbox" checked={!!ctx.state.checked[`developer-provided-${item}`]} onChange={() => ctx.toggleCheck(`developer-provided-${item}`)}/><span className="small">Information provided by developer</span></label>
      <label className="check-row"><input className="check-control" type="checkbox" checked={ind} onChange={() => ctx.toggleCheck(`independent-${item}`)}/><span className="small">Independently verified</span></label></div>; })}</div>
    <p className="small muted" style={{ marginTop: 12 }}>{verified} of {items.length} independently verified</p>
    <div className="callout warning-callout" style={{ marginTop: 10 }}><strong>Avoid</strong><p className="small" style={{ margin: '5px 0 0' }}>Treating developer-provided information as independently verified.</p></div>
    <div style={{ marginTop: 14 }}><button className="btn" onClick={() => ctx.openExperts('Property Lawyer')}>Need help verifying this? Find a Property Lawyer <ArrowRight size={15}/></button></div>
  </div>;
}

/* ---------- Projects ---------- */
type ProjectDraft = Omit<Project, 'id' | 'kind'>;
const blankDraft: ProjectDraft = { name: '', developer: '', location: '', configuration: '', area: '', price: '', possession: '', rera: '', amenities: '', parking: '', maintenance: '', connectivity: '', schoolHealthcare: '', reputation: '', constructionQuality: '', customerFeedback: '', legalStatus: '', financialStability: '', trackRecord: '', infrastructure: '' };
const fieldList: [keyof ProjectDraft, string][] = [
  ['name', 'Project name'], ['developer', 'Developer'], ['location', 'Location'], ['configuration', 'Configuration'],
  ['area', 'Carpet area (sq ft)'], ['price', 'Total price (₹)'], ['possession', 'Possession'], ['rera', 'RERA'],
  ['amenities', 'Amenities'], ['parking', 'Parking'], ['maintenance', 'Maintenance'], ['connectivity', 'Connectivity'],
  ['schoolHealthcare', 'School / healthcare'], ['reputation', 'Developer reputation'], ['constructionQuality', 'Construction quality'],
  ['customerFeedback', 'Customer feedback'], ['legalStatus', 'Legal status'], ['financialStability', 'Financial stability'],
  ['trackRecord', 'Track record'], ['infrastructure', 'Government infrastructure proximity'],
];
function perSqFt(p: ProjectDraft) {
  const a = Number(p.area), pr = Number(p.price);
  return a > 0 && pr > 0 && Number.isFinite(a) && Number.isFinite(pr) ? `${currency(pr / a)} / sq ft` : 'Add carpet area and price';
}
function displayValue(p: ProjectDraft, k: keyof ProjectDraft) {
  const v = p[k];
  if (!v) return 'Not entered';
  return k === 'price' ? currency(Number(v)) : k === 'area' ? `${v} sq ft` : v;
}

function ProjectManager({ ctx, kind }: { ctx: Ctx; kind: Kind }) {
  const { state, setState } = ctx;
  const list = state.projects.filter(p => (p.kind ?? 'new') === kind);
  const cmpKey = `compare-${kind}`;
  const compared = list.filter(p => (state.selected[cmpKey] || []).includes(String(p.id)));
  const [openId, setOpenId] = useState<number | null>(null);
  const [dialog, setDialog] = useState<{ id: number | null; draft: ProjectDraft } | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const noun = kind === 'new' ? 'project' : 'property';

  const save = () => {
    if (!dialog) return;
    const d = dialog.draft, errs: string[] = [];
    if (!d.name.trim()) errs.push(`Enter a ${noun} name.`);
    if (numError(d.area)) errs.push('Carpet area must be a non-negative number.');
    if (numError(d.price)) errs.push('Total price must be a non-negative number.');
    if (errs.length) { setErrors(errs); return; }
    if (dialog.id === null) {
      if (list.length >= 5) { setErrors(['You can add up to 5.']); return; }
      setState(s => ({ ...s, projects: [...s.projects, { ...d, id: Date.now(), kind }] }));
    } else {
      setState(s => ({ ...s, projects: s.projects.map(p => p.id === dialog.id ? { ...p, ...d } : p) }));
    }
    ctx.setToast(dialog.id === null ? 'Saved to your shortlist' : 'Details updated');
    setDialog(null); setErrors([]);
  };
  const remove = (p: Project) => {
    if (!window.confirm(`Remove ${p.name} from your shortlist?`)) return;
    setState(s => ({ ...s, projects: s.projects.filter(x => x.id !== p.id), selected: { ...s.selected, [cmpKey]: (s.selected[cmpKey] || []).filter(id => id !== String(p.id)) } }));
  };

  return <div className="grid">
    <div className="surface"><div className="section-title"><div><h2>{kind === 'new' ? 'Shortlist projects' : 'Shortlist property'}</h2><p className="small muted" style={{ margin: 0 }}>Add up to 5 to compare. {list.length} of 5 added.</p></div><button className="btn btn-primary" disabled={list.length >= 5} onClick={() => { setDialog({ id: null, draft: { ...blankDraft } }); setErrors([]); }}>Add {noun}</button></div>
      {list.length === 0 ? <div className="empty"><div className="icon-box"><Building2 size={20}/></div><h3>No {noun}s added yet</h3><p className="small">Add details you have gathered yourself. Finnest does not provide or verify listings.</p></div> :
        list.map(p => <div className="surface" key={p.id} style={{ marginTop: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><div><h3>{p.name}</h3><div className="small muted">{p.developer || 'Developer not entered'} · {p.location || 'Location not entered'}</div></div>
            <label className="small" style={{ display: 'flex', gap: 8, alignItems: 'center', minHeight: 44 }}><input className="check-control" type="checkbox" checked={(state.selected[cmpKey] || []).includes(String(p.id))} onChange={() => ctx.togglePick(cmpKey, String(p.id))}/> Compare</label></div>
          <div className="small" style={{ marginTop: 10 }}>{displayValue(p, 'configuration')} · {displayValue(p, 'area')} · {displayValue(p, 'price')} · {perSqFt(p)}</div>
          <div className="btn-row" style={{ marginTop: 6 }}>
            <button className="btn btn-quiet" aria-expanded={openId === p.id} onClick={() => setOpenId(openId === p.id ? null : p.id)}>{openId === p.id ? 'Hide full details' : 'View full details'} <ChevronDown size={15}/></button>
            <button className="btn btn-quiet" onClick={() => { const { id, kind: _k, ...draft } = p; setDialog({ id, draft }); setErrors([]); }}><Pencil size={15}/> Edit</button>
            <button className="btn btn-quiet" style={{ color: '#b42318' }} onClick={() => remove(p)}><Trash2 size={15}/> Remove</button>
          </div>
          {openId === p.id && <div className="grid two-col" style={{ borderTop: '1px solid #eceeeb', paddingTop: 12 }}>
            <div><div className="caption">Price per sq ft</div><div className="small">{perSqFt(p)}</div></div>
            {fieldList.filter(([k]) => !['name', 'price', 'area'].includes(k)).map(([k, label]) => <div key={k}><div className="caption">{label}</div><div className="small">{displayValue(p, k)}</div></div>)}</div>}
        </div>)}
      <p className="caption" style={{ marginTop: 12 }}>All details are entered by you. Finnest has not verified them.</p>
    </div>
    <div className="surface"><h2>Compare</h2>
      {list.length < 2 ? <p className="small muted">Add at least two to compare them side by side.</p> : compared.length < 2 ? <p className="small muted">Tick Compare on two or more to see them side by side.</p> :
        <div className="table-wrap"><table><thead><tr><th>Detail</th>{compared.map(p => <th key={p.id}>{p.name}</th>)}</tr></thead><tbody>
          {fieldList.filter(([k]) => k !== 'name').map(([k, label]) => <tr key={k}><td>{label}</td>{compared.map(p => <td key={p.id}>{displayValue(p, k)}</td>)}</tr>)}
          <tr><td>Price per sq ft</td>{compared.map(p => <td key={p.id}>{perSqFt(p)}</td>)}</tr></tbody></table></div>}
    </div>
    {dialog && <Modal title={dialog.id === null ? `Add ${noun}` : `Edit ${noun}`} onClose={() => setDialog(null)}>
      <p className="small muted">Only enter what you have gathered. Leave anything else blank.</p>
      <div className="field-grid">{fieldList.map(([k, label]) => <Field key={k} label={label} id={`pf-${k}`}><input id={`pf-${k}`} className="input" value={dialog.draft[k]} inputMode={k === 'area' || k === 'price' ? 'decimal' : undefined} onChange={e => setDialog({ ...dialog, draft: { ...dialog.draft, [k]: e.target.value } })}/></Field>)}</div>
      {errors.length > 0 && <ErrorNote>{errors.map(e => <div key={e}>{e}</div>)}</ErrorNote>}
      <div className="btn-row" style={{ marginTop: 18 }}><button className="btn" onClick={() => setDialog(null)}>Cancel</button><button className="btn btn-primary" onClick={save}>Save details</button></div>
    </Modal>}
  </div>;
}

/* ---------- Site visit + resident feedback ---------- */
function ResidentFeedback({ ctx }: { ctx: Ctx }) {
  const { state, setState, putNote } = ctx;
  const projects = state.projects.filter(p => (p.kind ?? 'new') === 'new');
  const pid = projects.find(p => String(p.id) === state.values.residentProject)?.id ?? projects[0]?.id;
  const answers = residentQs.map((_, i) => state.selected[`res-${pid}-${i}`]?.[0]);
  const tally = (a: string) => answers.filter(x => x === a).length;
  return <div className="surface"><div className="eyebrow">RESIDENT FEEDBACK</div><h2 style={{ marginTop: 8 }}>Talk to 8–10 residents</h2>
    <p className="small muted">Record what residents tell you, one shortlisted project at a time. These are your own notes, not verified ratings.</p>
    {pid === undefined ? <div className="empty"><div className="icon-box"><Building2 size={19}/></div><h3>No shortlisted projects</h3><p className="small">Add a project in Shortlist Projects to record resident feedback for it.</p><button className="btn btn-primary" onClick={() => ctx.openStep(2)}>Go to Shortlist Projects</button></div> : <>
      <Field label="Project" id="res-project"><select id="res-project" className="select" value={String(pid)} onChange={e => ctx.putValue('residentProject', e.target.value)}>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
      <div style={{ marginTop: 14 }}>{residentQs.map((q, i) => { const key = `res-${pid}-${i}`; return <div className="accordion" key={`${pid}-${q}`}><div style={{ padding: '12px 0' }}><strong>{q}</strong>
        <div className="pill-select" role="group" aria-label={q} style={{ marginTop: 10 }}>{['Yes', 'No', 'Not sure'].map(a => <button key={a} aria-pressed={answers[i] === a} className={`pill ${answers[i] === a ? 'selected' : ''}`} onClick={() => setState(s => ({ ...s, selected: { ...s.selected, [key]: s.selected[key]?.[0] === a ? [] : [a] } }))}>{a}</button>)}</div>
        <input className="input" aria-label={`Notes for: ${q}`} style={{ marginTop: 9 }} value={state.notes[key] || ''} onChange={e => putNote(key, e.target.value)} placeholder="Notes (optional)"/></div></div>; })}</div>
      <div className="soft-surface" style={{ marginTop: 18 }}><strong>Resident feedback summary</strong><p className="small muted" style={{ margin: '5px 0 0' }}>{answers.filter(Boolean).length} of {residentQs.length} answered · Yes {tally('Yes')} · No {tally('No')} · Not sure {tally('Not sure')}</p></div></>}
  </div>;
}

function SiteVisit({ ctx }: { ctx: Ctx }) {
  const done = siteItems.filter(i => ctx.state.checked[`site-${i}`]).length;
  return <div className="grid"><div className="surface"><div className="eyebrow">SITE VISIT CHECKLIST</div><h2 style={{ marginTop: 8 }}>What to observe during a visit</h2><p className="small muted">Tap each item once you have reviewed it. Leave notes while details are fresh.</p>
    <div className="progress-track"><div className="progress-fill" style={{ width: `${done / siteItems.length * 100}%` }}/></div><p className="small muted">{done} / {siteItems.length} checked</p>
    <CheckList ctx={ctx} items={siteItems} prefix="site"/>
    <Field label="Visit notes" id="site-notes"><textarea id="site-notes" className="textarea" value={ctx.state.notes.site || ''} onChange={e => ctx.putNote('site', e.target.value)} placeholder="Add your observations…"/></Field></div>
    <ResidentFeedback ctx={ctx}/></div>;
}

/* ---------- Loans ---------- */
const lenderRows = ['Lender name', 'Interest rate', 'Fixed/floating', 'Processing fee', 'Prepayment terms', 'Tenure', 'EMI', 'Total interest', 'Other charges'];
function LenderTable({ ctx }: { ctx: Ctx }) {
  return <div className="surface"><h2>Lender comparison</h2><p className="small muted">No lender names, offers or rates are supplied. Enter terms you receive directly from lenders.</p>
    <div className="table-wrap"><table><thead><tr><th>Compare</th><th>Option 1</th><th>Option 2</th><th>Option 3</th></tr></thead><tbody>{lenderRows.map(r => <tr key={r}><td>{r}</td>{['1', '2', '3'].map(n => <td key={n}><input aria-label={`${r}, option ${n}`} className="input" value={ctx.state.values[`loancomp-${r}-${n}`] || ''} onChange={e => ctx.putValue(`loancomp-${r}-${n}`, e.target.value)} placeholder="Add details"/></td>)}</tr>)}</tbody></table></div></div>;
}
function LoanCalculator({ ctx }: { ctx: Ctx }) {
  const { state, putValue } = ctx;
  const keys = ['income', 'loanamount', 'rate', 'tenure'];
  const invalid = anyError(state, keys);
  const principal = num(state, 'loanamount'), rate = num(state, 'rate'), years = num(state, 'tenure'), income = num(state, 'income');
  const emi = emiFor(principal, rate, years);
  const total = emi * years * 12;
  return <div className="surface"><div className="eyebrow">HOME LOAN CALCULATOR</div><h2 style={{ marginTop: 8 }}>Explore an estimate</h2><p className="small muted">Enter your assumptions. Results are illustrative calculations only.</p>
    <div className="field-grid"><NumField label="Monthly income" k="income" state={state} putValue={putValue}/><NumField label="Loan amount" k="loanamount" state={state} putValue={putValue}/><NumField label="Interest rate (% per year)" k="rate" state={state} putValue={putValue}/><NumField label="Tenure (years)" k="tenure" state={state} putValue={putValue}/></div>
    {invalid ? <ErrorNote>One or more values are negative or not valid numbers. Correct them to see results.</ErrorNote> : <>
      <div className="grid three-col" style={{ marginTop: 20 }}><Metric label="Monthly EMI" value={currency(emi)}/><Metric label="Total interest payable" value={currency(Math.max(0, total - principal))}/><Metric label="Total amount payable" value={currency(total)}/></div>
      {principal > 0 && years <= 0 && <ErrorNote>Enter a tenure greater than zero to calculate.</ErrorNote>}
      {emi > 0 && income > 0 && <p className="small muted" style={{ marginTop: 12 }}>This EMI is {(emi / income * 100).toFixed(1)}% of the monthly income you entered.</p>}</>}
    <p className="disclaimer" style={{ marginTop: 17 }}>{disclaimer}</p></div>;
}
function LoanDocs({ ctx }: { ctx: Ctx }) {
  return <div><h2>Typical documents required</h2><CheckList ctx={ctx} prefix="loan-doc" items={['Identity documents', 'Address documents', 'Income documents', 'Bank statements', 'Property documents']}/><p className="caption">Requirements vary. Confirm directly with your lender.</p></div>;
}
function LoanStep({ ctx }: { ctx: Ctx }) {
  return <div className="grid"><LoanCalculator ctx={ctx}/><LenderTable ctx={ctx}/><LoanDocs ctx={ctx}/></div>;
}

/* ---------- Legal ---------- */
function ReraAction({ ctx }: { ctx: Ctx }) {
  const url = (ctx.state.values.reraUrl || '').trim();
  let valid = false;
  try { valid = new URL(url).protocol === 'https:'; } catch { valid = false; }
  const touched = url.length > 0;
  return <div className="surface"><h2>RERA verification</h2>
    <p className="small muted">Find your state's official RERA portal yourself, then paste its https address below. The link is provided by you and is not verified by Finnest.</p>
    <Field label="Official state RERA portal URL (https)" id="rera-url" error={touched && !valid ? 'Enter a valid https:// address.' : ''}><input id="rera-url" className="input" inputMode="url" value={ctx.state.values.reraUrl || ''} onChange={e => ctx.putValue('reraUrl', e.target.value)} placeholder="https://"/></Field>
    <div className="btn-row" style={{ marginTop: 12 }}>{valid ? <a className="btn btn-primary" href={url} target="_blank" rel="noopener noreferrer">Open portal in a new tab <ExternalLink size={15}/></a> : <button className="btn" disabled>Open portal in a new tab <ExternalLink size={15}/></button>}</div></div>;
}
function LegalItem({ ctx, item, why, verify }: { ctx: Ctx; item: string; why: string; verify: string }) {
  const open = !!ctx.expanded[`legal-${item}`];
  const done = !!ctx.state.checked[`legal-${item}`];
  return <div className="accordion"><div style={{ display: 'flex', gap: 12, alignItems: 'center', padding: '12px 0' }}><input className="check-control" aria-label={`${item} reviewed`} type="checkbox" checked={done} onChange={() => ctx.toggleCheck(`legal-${item}`)}/><div style={{ flex: 1 }}><strong>{item}</strong><div className="caption">{done ? 'Reviewed' : 'Verification pending'}</div></div><button className="btn" aria-expanded={open} aria-label={`Details for ${item}`} onClick={() => ctx.setExpanded({ ...ctx.expanded, [`legal-${item}`]: !open })}><ChevronDown size={16}/></button></div>
    {open && <div className="accordion-content"><strong>Why it matters</strong><p>{why}</p><strong>What to verify</strong><p>{verify}</p>
      <Field label="Notes" id={`ln-${item}`}><textarea id={`ln-${item}`} className="textarea" value={ctx.state.notes[`legal-${item}`] || ''} onChange={e => ctx.putNote(`legal-${item}`, e.target.value)} placeholder="Optional notes"/></Field>
      <button className="btn btn-quiet" onClick={() => ctx.openExperts('Property Lawyer')}>Need help verifying this? Find a Property Lawyer <ArrowRight size={15}/></button></div>}</div>;
}
function LegalStep({ ctx }: { ctx: Ctx }) {
  return <div className="grid"><div className="soft-surface"><h2>Hire the Right Property Lawyer</h2><p className="small muted">Consider seeking independent legal advice for your circumstances.</p><button className="btn btn-primary" onClick={() => ctx.openExperts('Property Lawyer')}>Find a Property Lawyer <ArrowRight size={16}/></button></div>
    <div className="surface"><div className="section-title"><div><h2>Legal due diligence</h2><p className="small muted" style={{ margin: 0 }}>A checklist to discuss with a qualified professional.</p></div><BadgeCheck size={20} color="#0A7C66"/></div>{legalItems.map(([item, why, verify]) => <LegalItem key={item} ctx={ctx} item={item} why={why} verify={verify}/>)}</div>
    <ReraAction ctx={ctx}/><Disclaimer/></div>;
}

/* ---------- Financial ---------- */
function TrueCost({ ctx }: { ctx: Ctx }) {
  const { state, putValue } = ctx;
  const items: [string, string][] = [['Property price', 'tcprice'], ['Taxes', 'tctax'], ['Stamp duty', 'tcstamp'], ['Registration', 'tcreg'], ['Parking', 'tcparking'], ['Maintenance deposit', 'tcmaint'], ['Society charges', 'tcsociety'], ['Legal fees', 'tclawyer'], ['Loan processing', 'tcprocessing'], ['Interiors', 'tcinteriors'], ['Other charges', 'tcother']];
  const invalid = anyError(state, items.map(i => i[1]));
  const total = items.reduce((a, [, k]) => a + num(state, k), 0);
  return <div className="grid"><div className="surface"><div className="eyebrow">TRUE-COST CALCULATOR</div><h2 style={{ marginTop: 8 }}>Look beyond the listed price</h2><p className="small muted">Enter costs you have been quoted or estimated. Values are your inputs, not verified amounts.</p>
    <div className="field-grid">{items.map(([label, k]) => <NumField key={k} label={label} k={k} state={state} putValue={putValue}/>)}</div>
    {invalid ? <ErrorNote>One or more values are negative or not valid numbers. Correct them to see the total.</ErrorNote> : <div className="soft-surface" style={{ marginTop: 18 }}><div className="caption">ESTIMATED TOTAL COST</div><motion.strong key={total} initial={{ opacity: 0.4, y: 4 }} animate={{ opacity: 1, y: 0 }} style={{ display: 'block', fontSize: 27, marginTop: 5 }}>{currency(total)}</motion.strong></div>}</div>
    <LenderTable ctx={ctx}/><Disclaimer/></div>;
}

function FinalStep({ ctx }: { ctx: Ctx }) {
  const items = ['Lawyer due diligence completed', 'CA/tax consultation completed where required', 'Loan sanction verified', 'Agreement reviewed', 'Promised specifications documented', 'Payment schedule understood', 'Possession terms understood', 'Cancellation/refund provisions understood', 'Additional charges understood', 'Original/required documents verified', 'Occupancy Certificate confirmed where applicable'];
  const done = items.filter(i => ctx.state.checked[`final-${i}`]).length;
  const pct = Math.round(done / items.length * 100);
  return <div className="grid"><div className="surface"><div className="eyebrow">FINAL VERIFICATION</div><h2 style={{ marginTop: 8 }}>Review before you decide</h2><p className="small muted">A checklist for your own review. A ticked item is not a professional verification.</p><CheckList ctx={ctx} items={items} prefix="final"/></div>
    <div className="surface"><div style={{ display: 'flex', justifyContent: 'space-between' }}><h3>Completion</h3><strong style={{ color: '#0A7C66' }}>{pct}%</strong></div><div className="progress-track" style={{ marginTop: 10 }}><motion.div className="progress-fill" animate={{ width: `${pct}%` }} transition={{ duration: .5 }}/></div><p className="small muted" style={{ margin: '10px 0 0' }}>{done} of {items.length} items reviewed</p>
      {done < items.length && <p className="small muted">Some items are still pending. Take the time you need.</p>}</div>
    {done === items.length && <div className="callout"><CheckCircle2 size={18} style={{ verticalAlign: 'middle' }}/> <strong>Ready to proceed?</strong><p className="small" style={{ margin: '6px 0 0' }}>You have reviewed every item. The decision remains yours; consult the professionals relevant to your situation before deciding.</p></div>}
    <Disclaimer/></div>;
}

/* ---------- Resale ---------- */
const resaleSections: { title: string; body: string; items: string[] }[] = [
  { title: 'Define requirements', body: 'Note your budget, location and configuration priorities.', items: ['Budget considered', 'Loan eligibility considered', 'Location priorities noted', 'Configuration preferences noted'] },
  { title: 'Shortlist property', body: 'Keep the details you have gathered together for each property.', items: ['Property details recorded', 'Asking price recorded', 'Seller details recorded', 'Documents requested'] },
  { title: 'Visit property', body: 'Review physical condition and the surroundings in person.', items: ['Physical condition reviewed', 'Water and electricity checked', 'Ventilation and natural light reviewed', 'Approach and surroundings reviewed'] },
  { title: 'Verify seller', body: 'Confirm seller identity and authority with professional guidance.', items: ['Seller identity reviewed', 'Authority to sell discussed', 'Details cross-checked with documents'] },
  { title: 'Verify title & ownership', body: 'Review ownership documents with a qualified property lawyer.', items: ['Ownership documents requested', 'Ownership details reviewed by lawyer', 'Title-related questions addressed'] },
  { title: 'Verify society documents', body: 'Request relevant society records and clarify what applies to the property.', items: ['Society documents requested', 'Transfer process clarified', 'Relevant approvals discussed'] },
  { title: 'Verify financial dues', body: 'Clarify any outstanding dues and charges with the relevant parties.', items: ['Society dues clarified', 'Utility dues clarified', 'Other charges recorded'] },
  { title: 'Check existing loan', body: 'If a loan exists, clarify the process and documents with the lender and lawyer.', items: ['Existing loan status clarified', 'Lender process discussed', 'Release documents clarified'] },
  { title: 'Legal due diligence', body: 'Seek independent legal review for your situation.', items: ['Lawyer appointed', 'Documents reviewed', 'Open questions resolved with lawyer'] },
  { title: 'Agreement', body: 'Have the agreement reviewed and understand the terms before signing.', items: ['Agreement reviewed', 'Payment terms understood', 'Conditions and timelines understood'] },
  { title: 'Home loan', body: 'Discuss eligibility and loan terms directly with lenders.', items: ['Loan terms compared', 'Costs understood', 'Sanction details reviewed'] },
  { title: 'Registration & transfer', body: 'Clarify registration and handover steps with the relevant professionals.', items: ['Registration process confirmed', 'Transfer requirements confirmed', 'Handover and keys planned'] },
];
function ResaleDetail({ ctx, step }: { ctx: Ctx; step: number }) {
  const s = resaleSections[step];
  const checklist = <div className="surface"><div className="eyebrow">RESALE CHECKLIST</div><h2 style={{ marginTop: 8 }}>{s.title}</h2><p className="small muted">{s.body}</p><CheckList ctx={ctx} items={s.items} prefix={`resale-${step}`}/>
    <Field label="Notes" id={`rn-${step}`}><textarea id={`rn-${step}`} className="textarea" value={ctx.state.notes[`resale-${step}`] || ''} onChange={e => ctx.putNote(`resale-${step}`, e.target.value)} placeholder="Record details and questions…"/></Field></div>;
  return <div className="grid">
    {step === 0 && <><BudgetSection ctx={ctx}/><LocationPicker ctx={ctx} group="resaleLocations"/><ConfigSection ctx={ctx}/></>}
    {step === 1 && <ProjectManager ctx={ctx} kind="resale"/>}
    {step === 8 && <div className="soft-surface"><h2>Hire the Right Property Lawyer</h2><button className="btn btn-primary" onClick={() => ctx.openExperts('Property Lawyer')}>Find a Property Lawyer <ArrowRight size={16}/></button></div>}
    {checklist}
    {step === 2 && <div className="callout"><strong>Physical condition</strong><p className="small" style={{ margin: '5px 0 0' }}>For technical questions, consider consulting a suitably qualified professional.</p><button className="btn btn-quiet" onClick={() => ctx.openExperts('Architect / Technical Expert')}>Find an Architect / Technical Expert <ArrowRight size={15}/></button></div>}
    {step === 8 && <ReraAction ctx={ctx}/>}
    {step === 10 && <><LoanCalculator ctx={ctx}/><LenderTable ctx={ctx}/><LoanDocs ctx={ctx}/></>}
    {[4, 5, 6, 7, 8, 9, 10, 11].includes(step) && <Disclaimer/>}
  </div>;
}

function NewDetail({ ctx, step }: { ctx: Ctx; step: number }) {
  if (step === 0) return <div className="grid"><BudgetSection ctx={ctx}/><LocationPicker ctx={ctx} group="location"/><ConfigSection ctx={ctx}/></div>;
  if (step === 1) return <DeveloperStep ctx={ctx}/>;
  if (step === 2) return <ProjectManager ctx={ctx} kind="new"/>;
  if (step === 3) return <SiteVisit ctx={ctx}/>;
  if (step === 4) return <LoanStep ctx={ctx}/>;
  if (step === 5) return <LegalStep ctx={ctx}/>;
  if (step === 6) return <TrueCost ctx={ctx}/>;
  return <FinalStep ctx={ctx}/>;
}

export function JourneyScreen({ ctx, journey, markDone }: { ctx: Ctx; journey: string[]; markDone: (i: number) => void }) {
  const { state, openStep } = ctx;
  const resale = state.propertyType === 'Resale Property';
  const step = Math.min(state.step, journey.length - 1);
  const done = !!state.checked[`stepdone-${step}`];
  const aside: ReactNode = resale
    ? (step === 10 ? <ContextExpert ctx={ctx} label="Need help comparing loans?" action="Talk to a Home Loan Advisor" category="Home Loan Advisor"/> : step === 8 || step === 4 ? <ContextExpert ctx={ctx} label="Need help verifying this?" action="Find a Property Lawyer" category="Property Lawyer"/> : null)
    : (step === 4 ? <ContextExpert ctx={ctx} label="Need help comparing loans?" action="Talk to a Home Loan Advisor" category="Home Loan Advisor"/> : step === 5 ? <ContextExpert ctx={ctx} label="Need help verifying this?" action="Find a Property Lawyer" category="Property Lawyer"/> : null);
  const sub = resale ? resaleSteps[step] : journey[step];
  return <><PageHead eyebrow={`${resale ? 'RESALE PROPERTY' : 'NEW PROPERTY'} · STEP ${step + 1} OF ${journey.length}`} title={sub} desc={step === 0 ? 'Set out what matters to you before you compare options.' : 'Work through what applies to your situation. Notes save automatically.'}/>
    <div className="section" style={{ marginTop: -12 }}><div className="progress-track"><div className="progress-fill" style={{ width: `${((step + 1) / journey.length) * 100}%` }}/></div></div>
    <div className="grid split">
      <div>
        {resale ? <ResaleDetail ctx={ctx} step={step}/> : <NewDetail ctx={ctx} step={step}/>}
        <div className="btn-row" style={{ marginTop: 22, justifyContent: 'space-between' }}><button className="btn" onClick={() => openStep(Math.max(0, step - 1))} disabled={step === 0}><ArrowLeft size={16}/> Previous</button>
          <div className="btn-row"><button className={`btn ${done ? '' : 'btn-primary'}`} onClick={() => markDone(step)}>{done ? <><Check size={16}/> Completed</> : 'Mark step complete'}</button>{step < journey.length - 1 && <button className="btn btn-primary" onClick={() => openStep(step + 1)}>Next step <ArrowRight size={16}/></button>}</div></div>
        <p className="floating-save"><ShieldCheck size={14}/> Your progress is saved on this device.</p>
      </div>
      <aside className="grid" style={{ gap: 14 }}>
        <div className="surface"><div className="section-title"><h3 style={{ margin: 0 }}>Journey map</h3><span className="badge">{journey.length} steps</span></div>{journey.map((item, i) => <button key={item} className="step-row" onClick={() => openStep(i)} aria-current={i === step ? 'step' : undefined} style={{ width: '100%', background: 'transparent', border: 0, textAlign: 'left' }}><span className={`step-number ${state.checked[`stepdone-${i}`] ? 'complete' : i === step ? 'current' : ''}`}>{state.checked[`stepdone-${i}`] ? <Check size={14}/> : i + 1}</span><span style={{ fontSize: 12, fontWeight: i === step ? 700 : 500 }}>{item}</span></button>)}</div>
        {aside}
        <div className="disclaimer">{disclaimer}</div>
      </aside>
    </div>
  </>;
}



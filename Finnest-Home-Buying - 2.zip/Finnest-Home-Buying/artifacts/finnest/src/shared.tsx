import { useEffect, useRef, type ReactNode } from 'react';
import { ChevronDown, X } from 'lucide-react';

export type Screen = 'Home' | 'Journey' | 'Experts' | 'About' | 'Documents' | 'Red Flags';
export type Profile = { name: string; city: string; family: string; children: boolean; elderly: boolean; firstTime: boolean };
export type Project = {
  id: number; kind: 'new' | 'resale';
  name: string; developer: string; location: string; configuration: string; area: string; price: string;
  possession: string; rera: string; amenities: string; parking: string; maintenance: string; connectivity: string;
  schoolHealthcare: string; reputation: string; constructionQuality: string; customerFeedback: string;
  legalStatus: string; financialStability: string; trackRecord: string; infrastructure: string;
};
export type ExpertRequest = { id: number; category: string; name: string; contact: string; message: string; savedAt: string };
export type AppState = {
  onboarded: boolean; propertyType: 'New Property' | 'Resale Property' | '';
  profile: Profile; activeScreen: Screen; step: number;
  checked: Record<string, boolean>; values: Record<string, string>; selected: Record<string, string[]>;
  notes: Record<string, string>; projects: Project[]; expertCategory: string; requests: ExpertRequest[];
};
export type Ctx = {
  state: AppState; setState: React.Dispatch<React.SetStateAction<AppState>>;
  toggleCheck: (k: string) => void; putValue: (k: string, v: string) => void; putNote: (k: string, v: string) => void;
  togglePick: (g: string, v: string) => void; openExperts: (category: string) => void; openStep: (i: number) => void;
  setToast: (s: string) => void; expanded: Record<string, boolean>; setExpanded: (e: Record<string, boolean>) => void;
};

export const blankProfile: Profile = { name: '', city: '', family: '', children: false, elderly: false, firstTime: false };
export const initialState: AppState = {
  onboarded: false, propertyType: '', profile: blankProfile, activeScreen: 'Home', step: 0,
  checked: {}, values: {}, selected: {}, notes: {}, projects: [], expertCategory: '', requests: [],
};
export const storageKey = 'finnest-local-v1';
export const newSteps = [
  'Define Your Requirements', 'Verify Developer', 'Shortlist Projects', 'Site Visit',
  'Home Loan', 'Legal Due Diligence', 'Financial Due Diligence', 'Final Verification',
];
export const resaleSteps = [
  'Define requirements', 'Shortlist property', 'Visit property', 'Verify seller',
  'Verify title & ownership', 'Verify society documents', 'Verify financial dues', 'Check existing loan',
  'Legal due diligence', 'Agreement', 'Home loan', 'Registration & transfer',
];
export const locations = ['Office accessibility', 'School', 'Healthcare', 'Public transport', "Parents' convenience", 'Shopping', 'Future appreciation', 'Peaceful environment', 'Connectivity'];
export const configurations = ['1 BHK', '2 BHK', '3 BHK', 'Villas / Duplexes'];
export const siteItems = ['Actual carpet area', 'Natural light', 'Ventilation', 'Noise', 'Water supply', 'Power backup', 'Parking', 'Lift capacity', 'Fire safety', 'Open spaces', 'Garden', "Children's play area", 'Senior citizen facilities', 'Security', 'Construction quality', 'Approach road', 'Surrounding development'];
export const residentQs = ['Are you satisfied with the developer?', 'Was possession delivered as promised?', 'Were there unexpected/hidden costs?', 'How is the construction quality holding up?', 'How does society management function?', 'Are there water/electricity issues?', 'How responsive is the developer?', 'Are there ongoing maintenance problems?', 'Would you recommend this project?'];
export const legalItems = [
  ['Chain of ownership', 'Review the ownership history with a property lawyer.', 'Ask the lawyer to review the relevant chain documents.'],
  ['Original sale deed', 'The sale deed records a transfer of ownership.', 'Confirm the original and supporting records with your lawyer.'],
  ['Title documents', 'Understand the title position before proceeding.', 'Have a qualified property lawyer review the documents.'],
  ['Encumbrance check', 'Check for recorded claims or interests as advised by counsel.', 'Ask a property lawyer how to conduct and interpret this check.'],
  ['Approved plan', 'Compare the available plan with the property details.', 'Confirm approvals with the relevant authority or your lawyer.'],
  ['RERA registration', 'Check the project registration where applicable.', 'Use the official state RERA portal and verify details independently.'],
  ['RERA disclosures', 'Review disclosures made for the project where applicable.', 'Compare the disclosures with documents and seek professional advice.'],
];
export const newRedFlags = ['Seller/builder pressure', 'Verbal promises', 'Refusal of independent verification', 'Missing RERA', 'Non-escrow payments', 'Unclear land title'];
export const resaleRedFlags = ['Seller pressure to decide quickly', 'Ownership details that do not match documents', 'Refusal to share relevant records', 'Unclear society dues', 'Existing loan details not clarified', 'Requests to proceed before independent review'];
export const expertTypes = ['Property Lawyer', 'Chartered Accountant', 'Home Loan Advisor', 'Property Consultant', 'Architect / Technical Expert', 'Interior Expert', 'Valuation Expert', 'Astrologer', 'Vastu Expert'];
export const disclaimer = 'This app provides general guidance. It is not a substitute for professional legal, financial or tax advice.';

export function readState(): AppState {
  try {
    const saved = localStorage.getItem(storageKey);
    if (!saved) return initialState;
    const parsed = JSON.parse(saved);
    return { ...initialState, ...parsed, profile: { ...blankProfile, ...parsed.profile } };
  } catch { return initialState; }
}
export function currency(n: number) {
  if (!Number.isFinite(n) || n <= 0) return '₹0';
  return `₹${Math.round(n).toLocaleString('en-IN')}`;
}
/** Returns an error message when a raw input is negative or not a finite number. */
export function numError(raw: string | undefined): string {
  if (raw === undefined || raw === '') return '';
  const n = Number(raw);
  if (!Number.isFinite(n)) return 'Enter a valid number.';
  if (n < 0) return 'Negative values are not accepted.';
  return '';
}
export function num(state: AppState, key: string) {
  const raw = state.values[key];
  if (numError(raw)) return 0;
  return Number(raw || 0) || 0;
}
export function anyError(state: AppState, keys: string[]) { return keys.some(k => numError(state.values[k])); }
export function emiFor(principal: number, annualRate: number, years: number) {
  const n = years * 12;
  if (principal <= 0 || n <= 0) return 0;
  const r = annualRate / 1200;
  if (r === 0) return principal / n;
  return principal * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
}
export function loanFromEmi(emi: number, annualRate: number, years: number) {
  const n = years * 12;
  if (emi <= 0 || n <= 0) return 0;
  const r = annualRate / 1200;
  if (r === 0) return emi * n;
  return emi * (1 - Math.pow(1 + r, -n)) / r;
}

export function Field({ label, children, error, id }: { label: string; children: ReactNode; error?: string; id?: string }) {
  return <div className="field"><label htmlFor={id}>{label}</label>{children}{error && <span className="small" role="alert" style={{ color: '#b42318' }}>{error}</span>}</div>;
}
export function NumField({ label, k, state, putValue, placeholder = 'Enter amount' }: { label: string; k: string; state: AppState; putValue: (k: string, v: string) => void; placeholder?: string }) {
  const err = numError(state.values[k]);
  const id = `f-${k}`;
  return <Field label={label} error={err} id={id}><input id={id} className="input" type="number" min="0" inputMode="decimal" aria-invalid={!!err} value={state.values[k] || ''} onChange={e => putValue(k, e.target.value)} placeholder={placeholder} style={err ? { borderColor: '#D92D20' } : undefined}/></Field>;
}
export function PageHead({ eyebrow, title, desc }: { eyebrow?: string; title: string; desc?: string }) {
  return <div className="page-head"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{desc && <p className="subhead">{desc}</p>}</div>;
}
export function Accordion({ title, children, open, toggle }: { title: string; children: ReactNode; open: boolean; toggle: () => void }) {
  return <div className="accordion"><button className="accordion-trigger" onClick={toggle} aria-expanded={open}>{title}<ChevronDown size={17} style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform .2s' }}/></button>{open && <div className="accordion-content">{children}</div>}</div>;
}
export function Metric({ label, value }: { label: string; value: string }) {
  return <div className="soft-surface"><div className="caption">{label}</div><strong style={{ display: 'block', fontSize: 18, marginTop: 6 }}>{value}</strong></div>;
}
export function ErrorNote({ children }: { children: ReactNode }) { return <div role="alert" className="callout danger-callout" style={{ marginTop: 14 }}>{children}</div>; }

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const root = ref.current;
    const focusables = () => Array.from(root?.querySelectorAll<HTMLElement>('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])') ?? []).filter(el => !el.hasAttribute('disabled'));
    (focusables()[1] ?? focusables()[0])?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); closeRef.current(); return; }
      if (e.key !== 'Tab') return;
      const items = focusables();
      if (!items.length) return;
      const first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKey);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = overflow; previous?.focus(); };
  }, []);
  return <div style={{ position: 'fixed', inset: 0, zIndex: 80, background: 'rgba(17,17,17,.35)', display: 'grid', placeItems: 'center', padding: 16 }} onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className="surface" style={{ width: 'min(100%,620px)', maxHeight: '90dvh', overflow: 'auto' }}>
      <div className="section-title"><h2 style={{ margin: 0 }}>{title}</h2><button className="btn" aria-label="Close dialog" onClick={onClose}><X size={17}/></button></div>
      {children}
    </div>
  </div>;
}

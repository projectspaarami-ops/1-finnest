import { useEffect, useState } from 'react';
import { JourneyScreen } from '@/journey';
import { ExpertsScreen } from '@/experts';
import { Accordion, Field, PageHead, newRedFlags, resaleRedFlags, newSteps, resaleSteps, readState, storageKey, disclaimer, type AppState, type Screen } from '@/shared';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, BadgeCheck, Banknote, Building2, Check, CheckCircle2,
  ChevronDown, ChevronRight, CircleHelp, ClipboardCheck, FileText,
  Home as HomeIcon, Landmark, MapPin, Scale, ShieldCheck, Sparkles,
  TriangleAlert, UsersRound, X,
} from 'lucide-react';


export default function App() {
  const [state, setState] = useState<AppState>(readState);
  const [showSplash, setShowSplash] = useState(!state.onboarded);
  const [onboardStage, setOnboardStage] = useState(state.onboarded ? 0 : 1);
  const [toast, setToast] = useState('');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  useEffect(() => { localStorage.setItem(storageKey, JSON.stringify(state)); }, [state]);
  useEffect(() => { const timer = window.setTimeout(() => setShowSplash(false), 850); return () => window.clearTimeout(timer); }, []);
  useEffect(() => { document.title = `${state.onboarded ? `${state.activeScreen} — ` : ''}Finnest — Game of Home Buying`; }, [state.activeScreen, state.onboarded]);
  useEffect(() => { if (!toast) return undefined; const t = window.setTimeout(() => setToast(''), 2600); return () => clearTimeout(t); }, [toast]);
  const journey = state.propertyType === 'Resale Property' ? resaleSteps : newSteps;
  const totalSteps = journey.length;
  const completedSteps = journey.reduce((acc, _, i) => acc + (state.checked[`stepdone-${i}`] ? 1 : 0), 0);
  const nextStep = Math.min(totalSteps - 1, journey.findIndex((_, i) => !state.checked[`stepdone-${i}`]) < 0 ? totalSteps - 1 : journey.findIndex((_, i) => !state.checked[`stepdone-${i}`]));
  const toggleCheck = (key: string) => setState(s => ({ ...s, checked: { ...s.checked, [key]: !s.checked[key] } }));
  const putValue = (key: string, val: string) => setState(s => ({ ...s, values: { ...s.values, [key]: val } }));
  const putNote = (key: string, val: string) => setState(s => ({ ...s, notes: { ...s.notes, [key]: val } }));
  const togglePick = (group: string, value: string) => setState(s => {
    const values = s.selected[group] || [];
    return { ...s, selected: { ...s.selected, [group]: values.includes(value) ? values.filter(v => v !== value) : [...values, value] } };
  });
  const nav = (screen: Screen) => { setState(s => ({ ...s, activeScreen: screen })); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const openStep = (i: number) => { setState(s => ({ ...s, activeScreen: 'Journey', step: i })); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const openExperts = (category: string) => { setState(s => ({ ...s, activeScreen: 'Experts', expertCategory: category })); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const markDone = (i = state.step) => { toggleCheck(`stepdone-${i}`); setToast(state.checked[`stepdone-${i}`] ? 'Step marked as in progress' : 'Progress saved'); };

  if (showSplash) return <main style={{ minHeight: '100dvh', display: 'grid', placeItems: 'center', textAlign: 'center' }}><motion.div initial={{ opacity: 0, scale: .96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .3 }}><div className="brand" style={{ justifyContent: 'center' }}><span className="brand-mark"><HomeIcon size={18}/></span>Finnest</div><p className="small muted">Game of Home Buying</p></motion.div></main>;
  if (!state.onboarded) return <Onboarding state={state} setState={setState} stage={onboardStage} setStage={setOnboardStage} />;

  const renderScreen = () => {
    if (state.activeScreen === 'Home') return <Dashboard state={state} journey={journey} completed={completedSteps} next={nextStep} openStep={openStep} nav={nav} />;
    if (state.activeScreen === 'Journey') return <JourneyScreen ctx={{ state, setState, toggleCheck, putValue, putNote, togglePick, openExperts, openStep, setToast, expanded, setExpanded }} journey={journey} markDone={markDone} />;
    if (state.activeScreen === 'Experts') return <ExpertsScreen state={state} setState={setState} nav={nav} setToast={setToast} />;
    if (state.activeScreen === 'About') return <AboutScreen expanded={expanded} setExpanded={setExpanded} />;
    if (state.activeScreen === 'Documents') return <DocumentsScreen state={state} toggleCheck={toggleCheck} />;
    return <RedFlagsScreen state={state} toggleCheck={toggleCheck} />;
  };
  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => nav('Home')} aria-label="Finnest home"><span className="brand-mark"><HomeIcon size={17}/></span><span>Finnest</span></button>
      <nav className="desktop-nav" aria-label="Primary navigation">{(['Home', 'Journey', 'Experts', 'About'] as Screen[]).map((n, i) => <NavButton key={n} name={n} active={state.activeScreen === n} onClick={() => nav(n)} />)}</nav>
      <button className="btn btn-quiet" onClick={() => nav('Documents')}><FileText size={17}/> <span className="desktop-label">Documents</span></button>
    </header>
    <main className="main-wrap">
      <AnimatePresence mode="wait"><motion.div key={`${state.activeScreen}-${state.step}`} initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: .2 }}>{renderScreen()}</motion.div></AnimatePresence>
    </main>
    <nav className="mobile-bottom" aria-label="Primary navigation">{(['Home', 'Journey', 'Experts', 'About'] as Screen[]).map(n => <NavButton key={n} name={n} active={state.activeScreen === n} onClick={() => nav(n)} />)}</nav>
    {toast && <div className="toast-note" role="status">{toast}</div>}
  </div>;
}

function NavButton({ name, active, onClick }: { name: Screen; active: boolean; onClick: () => void }) {
  const Icon = name === 'Home' ? HomeIcon : name === 'Journey' ? ClipboardCheck : name === 'Experts' ? UsersRound : CircleHelp;
  return <button className={`nav-btn ${active ? 'active' : ''}`} onClick={onClick} aria-current={active ? 'page' : undefined}><Icon size={18}/><span>{name}</span></button>;
}

function Onboarding({ state, setState, stage, setStage }: { state: AppState; setState: React.Dispatch<React.SetStateAction<AppState>>; stage: number; setStage: (n: number) => void }) {
  const [profile, setProfile] = useState(state.profile);
  const [type, setType] = useState<AppState['propertyType']>(state.propertyType);
  const [error, setError] = useState('');
  const advance = () => { if (stage === 1) setStage(2); else if (stage === 2) { if (!type) return setError('Choose a property type to continue.'); setError(''); setStage(3); } else { if (!profile.name.trim() || !profile.city.trim()) return setError('Add your name and city to continue.'); setState(s => ({ ...s, onboarded: true, profile, propertyType: type })); } };
  return <div className="onboard"><div className="onboard-inner">
    <div className="brand onboard-logo"><span className="brand-mark"><HomeIcon size={17}/></span>Finnest</div>
    <div className="onboard-card">
      {stage === 1 && <><div className="eyebrow">GAME OF HOME BUYING</div><h1>Buying a home shouldn't feel like a gamble.</h1><p className="subhead">Finnest helps Indian home buyers navigate the home-buying process step by step. Get guided, informed and organized—while you remain the decision-maker.</p><div className="divider"/><p className="small muted">Don't just buy a home. Follow the process.</p><button className="btn btn-primary" onClick={advance}>Start your journey <ArrowRight size={17}/></button></>}
      {stage === 2 && <><div className="eyebrow">FIRST, YOUR JOURNEY</div><h1>What kind of home are you exploring?</h1><p className="subhead">Choose a path. You can review your details as you go.</p><div className="grid" style={{ marginTop: 23 }}>
        {(['New Property', 'Resale Property'] as const).map((t, i) => <button key={t} className={`type-option ${type === t ? 'selected' : ''}`} onClick={() => { setType(t); setError(''); }}><span className="icon-box">{i === 0 ? <Building2 size={20}/> : <HomeIcon size={20}/>}</span><span><strong>{t}</strong><br/><span className="small muted">{i === 0 ? 'Under Construction' : 'Existing Home'}</span></span>{type === t && <CheckCircle2 size={20} color="#0A7C66" style={{ marginLeft: 'auto' }}/>}</button>)}
      </div><div className="btn-row" style={{ marginTop: 22 }}><button className="btn" onClick={() => setStage(1)}><ArrowLeft size={16}/> Back</button><button className="btn btn-primary" onClick={advance}>Continue <ArrowRight size={16}/></button></div></>}
      {stage === 3 && <><div className="eyebrow">A LITTLE ABOUT YOU</div><h1>Make this journey yours.</h1><p className="subhead">Your answers help tailor the checklist. They stay in this browser.</p><div className="field-grid" style={{ marginTop: 22 }}>
        <Field label="Name"><input className="input" value={profile.name} onChange={e => setProfile({ ...profile, name: e.target.value })} placeholder="Your name"/></Field>
        <Field label="City"><input className="input" value={profile.city} onChange={e => setProfile({ ...profile, city: e.target.value })} placeholder="Your city"/></Field>
        <Field label="Family situation"><select className="select" value={profile.family} onChange={e => setProfile({ ...profile, family: e.target.value })}><option value="">Select (optional)</option><option>Living alone</option><option>Couple</option><option>Family</option><option>Other</option></select></Field>
      </div><div style={{ marginTop: 18 }} className="grid">
        <label className="check-row"><input className="check-control" type="checkbox" checked={profile.children} onChange={e => setProfile({ ...profile, children: e.target.checked })}/><span>Children</span></label>
        <label className="check-row"><input className="check-control" type="checkbox" checked={profile.elderly} onChange={e => setProfile({ ...profile, elderly: e.target.checked })}/><span>Elderly parents</span></label>
        <label className="check-row"><input className="check-control" type="checkbox" checked={profile.firstTime} onChange={e => setProfile({ ...profile, firstTime: e.target.checked })}/><span>First-time buyer</span></label>
      </div><div className="btn-row" style={{ marginTop: 20 }}><button className="btn" onClick={() => setStage(2)}><ArrowLeft size={16}/> Back</button><button className="btn btn-primary" onClick={advance}>See your journey <ArrowRight size={16}/></button></div></>}
      {error && <p className="small" style={{ color: '#b42318', margin: '14px 0 0' }} role="alert">{error}</p>}
    </div><p className="caption" style={{ textAlign: 'center', marginTop: 20 }}>{disclaimer}</p>
  </div></div>;
}
function Dashboard({ state, journey, completed, next, openStep, nav }: { state: AppState; journey: string[]; completed: number; next: number; openStep: (n: number) => void; nav: (s: Screen) => void }) {
  const greet = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';
  const percent = Math.round(completed / journey.length * 100);
  const recommended = journey[next];
  const recommendations = [
    ...(state.profile.children ? ["Children's play area", 'Garden', 'Open space', 'School accessibility', 'Safe internal movement', 'Recreational facilities'] : []),
    ...(state.profile.elderly ? ['Lift accessibility', 'Hospital proximity', 'Walking areas', 'Garden/open space', 'Seating areas', 'Low-step/easy-access areas', 'Public transport'] : []),
  ];
  return <>
    <PageHead eyebrow="YOUR HOME-BUYING JOURNEY" title={`${greet}${state.profile.name ? `, ${state.profile.name}` : ''}`} desc={`A clear next step, at your pace${state.profile.city ? ` · ${state.profile.city}` : ''}.`} />
    <section className="hero-panel">
      <div><div className="eyebrow">YOUR JOURNEY</div><h2 style={{ fontSize: 22, marginTop: 9 }}>{state.propertyType}</h2><p className="muted small">{completed} of {journey.length} steps completed</p><div className="progress-track" style={{ marginTop: 18 }}><div className="progress-fill" style={{ width: `${percent}%` }}/></div><button className="btn btn-quiet" style={{ marginTop: 14, paddingLeft: 0 }} onClick={() => nav('Journey')}>View your journey <ArrowRight size={16}/></button></div>
      <div className="hero-progress"><div className="ring" style={{ '--progress': `${percent * 3.6}deg` } as React.CSSProperties}><span className="ring-value">{percent}%</span></div><div><strong>{completed === journey.length ? 'Journey complete' : 'Progress saved'}</strong><p className="small muted" style={{ margin: '5px 0 0' }}>Your entries stay on this device.</p></div></div>
    </section>
    <section className="section"><div className="recommendation"><div className="eyebrow">RECOMMENDED NEXT ACTION</div><h2>{recommended}</h2><p style={{ margin: 0, color: '#d7eee6' }}>{recommended === 'Verify Developer' ? 'Review the information provided and what you have independently verified.' : 'Continue through the checklist and keep your notes together.'}</p><button className="btn" onClick={() => openStep(next)}>Continue <ArrowRight size={16}/></button></div></section>
    <section className="section"><div className="section-title"><h2>Your journey</h2><button className="btn btn-quiet" onClick={() => nav('Journey')}>All steps <ArrowRight size={15}/></button></div><div className="surface">
      {journey.map((step, i) => <button key={step} className="step-row" onClick={() => openStep(i)} style={{ width: '100%', background: 'transparent', border: 0, textAlign: 'left', cursor: 'pointer' }}><span className={`step-number ${state.checked[`stepdone-${i}`] ? 'complete' : i === next ? 'current' : ''}`}>{state.checked[`stepdone-${i}`] ? <Check size={16}/> : i + 1}</span><span><strong style={{ display: 'block', fontSize: 14 }}>{step}</strong><span className="caption">{state.checked[`stepdone-${i}`] ? 'Completed' : i === next ? 'Current step' : 'Upcoming'}</span></span><ChevronRight className="right-chevron" size={17}/></button>)}
    </div></section>
    {recommendations.length > 0 && <section className="section"><div className="section-title"><h2>Personalized recommendations</h2><span className="badge badge-green">Based on your profile</span></div><div className="surface"><p className="small muted">Consider these during visits and verification. Your priorities remain yours.</p><div className="pill-select">{recommendations.map(r => <span className="pill selected" key={r}>{r}</span>)}</div></div></section>}
    <section className="section"><div className="section-title"><h2>Useful places to start</h2></div><div className="grid three-col">
      <ActionCard icon={<FileText size={19}/>} title="Documents" text="Keep track of documents to gather and review." onClick={() => nav('Documents')}/>
      <ActionCard icon={<UsersRound size={19}/>} title="Experts" text="Explore the kinds of professionals who may help." onClick={() => nav('Experts')}/>
      <ActionCard icon={<TriangleAlert size={19}/>} title="Red Flags" text="Warning signs to pause and review." onClick={() => nav('Red Flags')}/>
    </div></section>
  </>;
}
function ActionCard({ icon, title, text, onClick }: { icon: React.ReactNode; title: string; text: string; onClick: () => void }) { return <button className="surface action-card" onClick={onClick}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}><span className="icon-box">{icon}</span><ChevronRight size={18} className="right-chevron"/></div><h3 style={{ marginTop: 17 }}>{title}</h3><p className="small muted" style={{ margin: 0 }}>{text}</p></button>; }



function DocumentsScreen({ state, toggleCheck }: { state: AppState; toggleCheck: (key: string) => void }) {
  const items = ['Identity documents', 'Address documents', 'Income documents', 'Bank statements', 'Property documents', 'Chain of ownership', 'Original sale deed', 'Title documents', 'Approved plan'];
  const count = items.filter(item => state.checked[`document-${item}`]).length;
  return <><PageHead eyebrow="YOUR DOCUMENTS" title="Documents" desc="A place to track what you have gathered and what still needs review."/><div className="grid split"><div className="surface">{items.map(item => <label className="check-row" key={item}><input className="check-control" type="checkbox" checked={!!state.checked[`document-${item}`]} onChange={() => toggleCheck(`document-${item}`)}/><span><strong>{item}</strong><span className="caption" style={{ display: 'block' }}>{state.checked[`document-${item}`] ? 'Marked as gathered' : 'Not marked yet'}</span></span></label>)}</div><div className="surface"><div className="eyebrow">DOCUMENT CHECKLIST</div><h2 style={{ marginTop: 8 }}>{count} of {items.length}</h2><div className="progress-track"><div className="progress-fill" style={{ width: `${count / items.length * 100}%` }}/></div><p className="small muted" style={{ marginTop: 12 }}>Checklist progress only; it does not verify authenticity or completeness.</p>{count === 0 && <div className="empty"><div className="icon-box"><FileText size={18}/></div><p className="small">No documents marked yet</p></div>}</div></div><p className="disclaimer" style={{ marginTop: 24 }}>{disclaimer}</p></>;
}

function RedFlagsScreen({ state, toggleCheck }: { state: AppState; toggleCheck: (key: string) => void }) {
  const list = state.propertyType === 'Resale Property' ? resaleRedFlags : newRedFlags;
  return <><PageHead eyebrow="PAUSE AND REVIEW" title="Red Flags" desc="Use these prompts to notice when you may need to pause and verify independently."/><div className="callout danger-callout alert-title"><TriangleAlert size={21}/><div><strong>Stop and obtain professional advice before proceeding.</strong><div className="small" style={{ marginTop: 4 }}>If you encounter a warning sign, pause and seek advice relevant to your situation.</div></div></div><div className="section"><div className="section-title"><h2>{state.propertyType === 'Resale Property' ? 'Resale property red flags' : 'New property red flags'}</h2></div><div className="grid two-col">{list.map(item => <label key={item} className="redflag"><input className="check-control" type="checkbox" checked={!!state.checked[`flag-${item}`]} onChange={() => toggleCheck(`flag-${item}`)}/><span><strong>{item}</strong><span className="small muted" style={{ display: 'block', marginTop: 5 }}>Noted for follow-up</span></span></label>)}</div></div><div className="surface"><h3>Action to take</h3><p className="small muted">Pause. Keep a written record of what raised concern, ask for documents or clarification, and seek independent professional advice before deciding how to proceed.</p></div></>;
}


function AboutScreen({ expanded, setExpanded }: any) {
  const questions = ['Where am I?', 'What have I completed?', 'What is pending?', 'What documents do I need?', 'What should I verify?', 'Why is this important?', 'Who can help me?', 'What should I do next?'];
  return <><PageHead eyebrow="ABOUT FINNEST" title="A steadier way to move forward" desc="Game of Home Buying"/><div className="hero-panel"><div><div className="eyebrow">OUR PHILOSOPHY</div><h2 style={{ fontSize: 27, marginTop: 10 }}>Don't just buy a home. Follow the process.</h2><p className="subhead">Finnest is a guided decision-support and checklist product. It helps you navigate the process step by step, while you remain the decision-maker.</p></div><div className="soft-surface"><ShieldCheck size={23} color="#0A7C66"/><h3 style={{ marginTop: 12 }}>Review. Verify. Decide.</h3><p className="small muted" style={{ margin: 0 }}>No pressure to purchase. Your pace, your decision.</p></div></div><section className="section"><div className="section-title"><h2>Eight questions, answered by every step</h2></div><div className="surface">{questions.map((q, i) => <Accordion key={q} title={q} open={!!expanded[`about-${i}`]} toggle={() => setExpanded({ ...expanded, [`about-${i}`]: !expanded[`about-${i}`] })}><p>{['Your current place in the home-buying process.', 'Steps and checklist items you have marked complete.', 'The next checklist items in your chosen journey.', 'Items to gather, based on the journey section.', 'Prompts to support your own verification.', 'A short explanation inside the relevant checklist.', 'Expert categories you may choose to explore.', 'A suggested next action, with no pressure to purchase.'][i]}</p></Accordion>)}</div></section><div className="callout"><strong>Disclaimer</strong><p className="small" style={{ margin: '6px 0 0' }}>{disclaimer}</p></div></>;
}
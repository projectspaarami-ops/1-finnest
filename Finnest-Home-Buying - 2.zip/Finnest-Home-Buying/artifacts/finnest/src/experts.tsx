import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Banknote, BadgeCheck, Building2, CircleHelp, ClipboardCheck, Landmark, MapPin, Scale, Sparkles, Trash2, UsersRound } from 'lucide-react';
import { Field, Modal, PageHead, expertTypes, type AppState, type Screen } from '@/shared';

const icons = [Scale, Banknote, Landmark, Building2, ClipboardCheck, Sparkles, BadgeCheck, CircleHelp, MapPin];

type Props = {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  nav: (s: Screen) => void;
  setToast: (s: string) => void;
};

export function ExpertsScreen({ state, setState, nav, setToast }: Props) {
  const [query, setQuery] = useState('');
  const [profile, setProfile] = useState<string | null>(null);
  const [request, setRequest] = useState<string | null>(null);
  const [form, setForm] = useState({ name: state.profile.name, contact: '', message: '' });
  const [error, setError] = useState('');
  const focusRef = useRef<HTMLDivElement>(null);
  const selected = state.expertCategory;
  useEffect(() => { focusRef.current?.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, [selected]);
  const filtered = expertTypes.filter(t => t.toLowerCase().includes(query.toLowerCase()));

  const save = () => {
    if (!form.name.trim() || !form.contact.trim()) { setError('Add your name and a phone number or email to save this request.'); return; }
    setState(s => ({ ...s, requests: [...s.requests, { id: Date.now(), category: request ?? '', name: form.name.trim(), contact: form.contact.trim(), message: form.message.trim(), savedAt: new Date().toLocaleString('en-IN') }] }));
    setRequest(null); setError(''); setForm(f => ({ ...f, contact: '', message: '' }));
    setToast('Request saved on this device only. It has not been sent.');
  };

  return <>
    <PageHead eyebrow="PROFESSIONAL SUPPORT" title="Experts" desc="Explore professional categories that may be relevant to your home-buying process. Provider listings are not available in this prototype."/>
    <div className="field" style={{ maxWidth: 420, marginBottom: 20 }}><label htmlFor="expert-search">Find a category</label><input id="expert-search" className="input" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search expert categories"/></div>
    {filtered.length ? <div className="grid two-col">{filtered.map(expert => {
      const Icon = icons[expertTypes.indexOf(expert)] ?? UsersRound;
      const active = selected === expert;
      return <div key={expert} ref={active ? focusRef : undefined} className="surface" style={active ? { borderColor: '#0A7C66', boxShadow: '0 0 0 2px #0A7C6620' } : undefined}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span className="icon-box"><Icon size={19}/></span>{active ? <span className="badge badge-green">Suggested for this step</span> : <span className="badge">Category</span>}</div>
        <h3 style={{ marginTop: 16 }}>{expert}</h3>
        <p className="small muted">Consider whether independent professional support may help. Finnest makes no claims about individual professionals.</p>
        <div className="btn-row"><button className="btn" onClick={() => setProfile(expert)}>View Profile</button><button className="btn btn-primary" onClick={() => { setRequest(expert); setError(''); }}>Contact Expert</button></div>
      </div>;
    })}</div> : <div className="surface empty"><div className="icon-box"><UsersRound size={20}/></div><h3>No matching categories</h3><button className="btn" onClick={() => setQuery('')}>Clear search</button></div>}

    <section className="section"><div className="section-title"><h2>Your saved requests</h2><span className="badge">Stored on this device</span></div>
      {state.requests.length === 0 ? <div className="surface empty"><div className="icon-box"><UsersRound size={19}/></div><p className="small">No requests saved. Requests are kept only in this browser and are never sent anywhere.</p></div> :
        <div className="surface">{state.requests.map(r => <div key={r.id} className="check-row"><div style={{ flex: 1 }}><strong>{r.category}</strong><div className="small muted">{r.name} · {r.contact} · {r.savedAt}</div>{r.message && <div className="small">{r.message}</div>}</div><button className="btn" aria-label={`Delete request for ${r.category}`} onClick={() => setState(s => ({ ...s, requests: s.requests.filter(x => x.id !== r.id) }))}><Trash2 size={16}/></button></div>)}</div>}
    </section>
    <div className="callout"><strong>Contextual support</strong><p className="small" style={{ margin: '5px 0 0' }}>Expert suggestions appear inside the journey where a professional may help.</p><button className="btn btn-quiet" onClick={() => nav('Journey')}>Return to your journey <ArrowRight size={15}/></button></div>

    {profile && <Modal title={`${profile} profiles`} onClose={() => setProfile(null)}>
      <span className="badge badge-amber">Prototype data</span>
      <div className="empty"><div className="icon-box"><UsersRound size={20}/></div><h3>No provider profiles available</h3><p className="small">This prototype has no backend, so there are no real provider profiles to show. A profile would list name, profession, years of experience, property transaction experience, expertise, location, credentials and services offered, supplied and verified by the provider.</p></div>
      <div className="btn-row"><button className="btn" onClick={() => setProfile(null)}>Close</button><button className="btn btn-primary" onClick={() => { const p = profile; setProfile(null); setRequest(p); }}>Save a request instead</button></div>
    </Modal>}
    {request && <Modal title={`Contact: ${request}`} onClose={() => setRequest(null)}>
      <div className="callout warning-callout" style={{ marginBottom: 16 }}>Prototype with no backend. Saving this only stores a note on this device. Nothing is sent to any expert.</div>
      <div className="grid">
        <Field label="Your name" id="req-name"><input id="req-name" className="input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}/></Field>
        <Field label="Phone or email" id="req-contact"><input id="req-contact" className="input" value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })}/></Field>
        <Field label="What do you need help with? (optional)" id="req-msg"><textarea id="req-msg" className="textarea" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}/></Field>
      </div>
      {error && <p className="small" role="alert" style={{ color: '#b42318' }}>{error}</p>}
      <div className="btn-row" style={{ marginTop: 16 }}><button className="btn" onClick={() => setRequest(null)}>Cancel</button><button className="btn btn-primary" onClick={save}>Save request on this device</button></div>
    </Modal>}
  </>;
}

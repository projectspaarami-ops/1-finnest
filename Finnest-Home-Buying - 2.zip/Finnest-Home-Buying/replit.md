# Finnest — Game of Home Buying

Finnest guides Indian home buyers through new-property and resale journeys. It is a decision-support and checklist product, not a property-selling platform.

## Run & Operate

- Managed workflow `artifacts/finnest: web` runs the frontend with its required routing environment.
- `pnpm --filter @workspace/finnest run typecheck` — frontend TypeScript check
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- The current prototype does not require backend services or credentials.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React, Vite, Tailwind CSS, Lucide icons, Framer Motion
- Shared Express/API/DB packages are available for future backend integration; they are not used to simulate prototype behavior.

## Where things live

- App: `artifacts/finnest/src`
- Original brief: `.local/conversation-workspace/files/attached_assets/Pasted-Build-a-complete-production-quality-responsive-mobile-f_1790935697795.txt`

## Architecture decisions

- The user explicitly requested local state for this prototype and no fake backend functionality. Backend-dependent features must make their limitations clear.
- Preserve supplied product content. The brief references detailed copy that was not supplied, including the Golden Rule and detailed configuration/Vastu guidance. Do not invent it or claim it was supplied.

## Product

Onboarding, personalized guidance, an eight-step new-property journey, a twelve-step resale journey, financial calculators, project shortlist and comparison, checklist/document tracking, resident feedback, red flags, expert categories, and About.

## User preferences

- Continue implementation from the current state; do not redesign completed screens.
- The user confirmed this is a native iOS/Android mobile app. Adapt the completed web prototype into native screens and controls, and keep the web version intact.
- Keep the app neutral and never pressure users to purchase. The user remains the decision-maker.
- Do not invent real projects, RERA numbers, lender offers, legal claims, professional credentials, statistics, or guarantees. Label necessary sample data “Prototype data”.
- Show general-guidance disclaimers on relevant legal and financial screens.
- Mobile-first. Native mobile styling follows the user's NoBroker reference with coral-pink actions, dark neutral text, white surfaces and light-gray secondary surfaces. The user explicitly removed green text and light-green backgrounds; keep the web version's existing Finnest styling intact.
- Hide the Finnest logo/brand header on every native app screen, retaining Back navigation except on Home.
- Home and Journey should show the same numbered Journey map with completion state and tappable steps.
- Personalized recommendations use rounded icon/radio chips. The home-loan calculator should use the supplied visual reference: sliders, a clear monthly EMI and a principal-versus-interest donut, rather than a generic form.
- Vastu is optional, never mandatory.

## Gotchas

- User-entered checklist completion is not independent professional verification.
- Do not add authentication or backend storage unless the scope changes explicitly.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
